package org.example;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Capcha extends Application {

    public static boolean c;
    private ArrayList correct = new ArrayList();

    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.setHgap(0);
        gridPane.setVgap(0);
        Random random = new Random();
        int randomNumber = random.nextInt(3);
        Button[][] buttons = new Button[4][4];
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                Button button = new Button();
                button.setPrefSize(100, 100);
                String name = String.valueOf(row)+String.valueOf(col);
                String address =  "/cap"+randomNumber+"/"+name+".png";
                Image image = new Image(getClass().getResource(address).toExternalForm());
                ImageView imageView = new ImageView(image);
                imageView.setFitWidth(100);
                imageView.setFitHeight(100);
                button.setGraphic(imageView);
                gridPane.add(button, col, row);
                buttons[row][col] = button;
                int currentRow = row;
                int currentCol = col;

//                Main.stage.setFullScreen(true);
//                Main.stage.initStyle(StageStyle.UNDECORATED);

                Main.stage.getScene().setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("ERROR");
                        alert.showAndWait();
                    }
                });

                button.setOnAction(event -> {
                    if (button.getStyle().contains("-fx-background-color: lightblue;")) {
                        button.setStyle("");
                        Iterator<String> iterator = correct.iterator();
                        while (iterator.hasNext()) {
                            String chackname = iterator.next();
                            if (chackname.equals(name)) {
                                iterator.remove();
                                break;
                            }
                        }
                    }
                    else {
                        button.setStyle("-fx-background-color: lightblue;");
                        correct.add(name);

                    }
                    ArrayList dorost = new ArrayList();
                    if(randomNumber==0)
                    {

                        dorost.add("01");
                        dorost.add("02");
                        dorost.add("03");
                    }
                    else if (randomNumber==1)
                    {
                        dorost.add("20");
                        dorost.add("21");
                        dorost.add("22");
                        dorost.add("23");
                        dorost.add("13");
                    }
                    else
                    {
                        dorost.add("00");
                        dorost.add("10");
                        dorost.add("01");
                        dorost.add("02");
                        dorost.add("03");
                        dorost.add("13");
                        dorost.add("12");
                    }
                    boolean areEqual = checkArrayListsEqualWithoutSort(correct, dorost);
                    if (areEqual) {
                        c = true;
                        primaryStage.close();
                        Main.stage.close();
                        if(Main.forget) {
                            try {
                                new Forget().start(Main.stage);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }
                        else {
                            try {
                                new Signup().start(Main.stage);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }

                    }


                });

            }
        }

        VBox vbox = new VBox(10, gridPane);
        vbox.setPadding(new Insets(10));

        Scene scene = new Scene(vbox);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private static <T> boolean checkArrayListsEqualWithoutSort(ArrayList<T> arrayList1, ArrayList<T> arrayList2) {
        if (arrayList1.size() != arrayList2.size()) {
            return false;
        }

        List<T> copyList = new ArrayList<>(arrayList1);

        for (T element : arrayList2) {
            if (copyList.contains(element)) {
                copyList.remove(element);
            } else {
                return false;
            }
        }

        return copyList.isEmpty();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
