package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.*;

public class CommentOrder extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/foodown2.jpg").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        anchorPane.setPrefWidth(400);
        anchorPane.setPrefHeight(400);

        TextField comment = new TextField(), rate = new TextField();
        comment.setPromptText("Comment");
        rate.setPromptText("Rate");

        Button add = new Button("Add");
        VBox comments;

        ListView<String> l = Food.getFoodComments();


        comment.setLayoutX(30);
        comment.setLayoutY(45);
        comment.setPrefWidth(150);
        comment.setPrefHeight(25);


        rate.setLayoutX(85);
        rate.setLayoutY(85);
        rate.setPrefWidth(40);
        rate.setPrefHeight(20);

        add.setLayoutX(85);
        add.setLayoutY(130);
        add.setPrefWidth(38);
        add.setPrefHeight(25);

        anchorPane.getChildren().addAll(comment, rate, add);


        add.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Costumer.addNewComment(comment.getText());
                Costumer.editRate(Integer.parseInt(rate.getText()));
                l.getItems().add(Costumer.loggedInCostumer.selectedFood.comments.get(Costumer.loggedInCostumer.selectedFood.comments.size() - 1).id + "        " + Costumer.loggedInCostumer.selectedFood.comments.get(Costumer.loggedInCostumer.selectedFood.comments.size() - 1).comment);
            }
        });

        comments = new VBox(l);
        comments.setLayoutX(220);
        comments.setLayoutY(45);
        comments.setPrefWidth(150);
        comments.setPrefHeight(340);

        anchorPane.getChildren().add(comments);

        Scene scene = new Scene(anchorPane);
        stage.setScene(scene);
        stage.show();

        stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());

                comment.setLayoutX(30 * Main.stage.getScene().getWidth() / 640);
                comment.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);

                rate.setLayoutX(85 * Main.stage.getScene().getWidth() / 640);
                rate.setPrefWidth(40 * Main.stage.getScene().getWidth() / 640);

                add.setLayoutX(85 * Main.stage.getScene().getWidth() / 640);
                add.setPrefWidth(38 * Main.stage.getScene().getWidth() / 640);

                comments.setLayoutX(220 * Main.stage.getScene().getWidth() / 640);
                comments.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);


            }
        });

        stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());

                comment.setLayoutY(45 * Main.stage.getScene().getHeight() / 360);
                comment.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                rate.setLayoutY(85 * Main.stage.getScene().getHeight() / 360);
                rate.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                add.setLayoutY(130 * Main.stage.getScene().getHeight() / 360);
                add.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                comments.setLayoutY(45 * Main.stage.getScene().getHeight() / 360);
                comments.setPrefHeight(340 * Main.stage.getScene().getHeight() / 360);

            }
        });


    }

}
