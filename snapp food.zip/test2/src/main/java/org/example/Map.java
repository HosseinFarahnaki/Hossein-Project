package org.example;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.*;
import javafx.scene.input.ScrollEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import logic.Graph;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Map extends Application {

    public static ArrayList<int[]> alldata;

    static {
        try {
            alldata = filereader();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    private Image imagelogo  = new Image(getClass().getResource("/maplogo.png").toExternalForm());
    private static final double MIN_SCALE = 0.1;
    private static final double MAX_SCALE = 10.0;
    private static final double ZOOM_FACTOR = 1.1;
    private ImageView imageView;
    private double scaleFactor = 1.0;

    private int start = 0;
    private int end = 0;

    // Create a new color using RGB values
    Color level1traffic = Color.rgb(0,128,255);
    Color level2traffic = Color.rgb(0,255,0);
    Color level3traffic = Color.rgb(255,125,0);
    Color level4traffic = Color.rgb(170,0,0);

    Color level1traffic2 = Color.rgb(0,128,255);
    Color level2traffic2 = Color.rgb(0,255,0);
    Color level3traffic2 = Color.rgb(255,125,0);
    Color level4traffic2 = Color.rgb(170,0,0);


    private double pointx1 = 0.0;
    private double pointy1 = 0.0;
    private double pointx2 = 0.0;
    private double pointy2 = 0.0;


    private ArrayList<int[]> allpoint = new ArrayList<>();

    public List path(int sar , int tah ,ArrayList<int[]> alldataarray) {
        int node = 1000;
        Graph graph = new Graph(node);
        //System.out.println(alldataarray.size());
        for (int i = 0; i < alldataarray.size(); i++) {
            int[] qqq = alldataarray.get(i);
            int source = (qqq[0]);
            int dest = (qqq[1]);
            int weight = (qqq[2]);
            graph.addEdge(source , dest , weight);
            //System.out.println(source+" "+dest+" "+weight);
        }
        List<Integer> shortestPath = graph.aStar(sar , tah );

//        int totalCost = 0 ;
//        for (int i = 0; i < shortestPath.size() - 1; i++) {
//            int a = shortestPath.get(i);
//            int b = shortestPath.get(i + 1);
//            totalCost += graph.getEdgeWeight(a,b);
//        }


        return shortestPath;

    }

    public List secondpath(int sar , int tah ,ArrayList<int[]> alldataarray) {
        int node = 1000;
        Graph graph = new Graph(node);
        //System.out.println(alldataarray.size());
        for (int i = 0; i < alldataarray.size(); i++) {
            int[] qqq = alldataarray.get(i);
            int source = (qqq[0]);
            int dest = (qqq[1]);
            int weight = (qqq[2]);
            graph.addEdge(source , dest , weight);
            //System.out.println(source+" "+dest+" "+weight);
        }
        List<Integer> secondshortestPath = graph.aStar(sar , tah );
        System.out.println(secondshortestPath);
        return secondshortestPath;

    }

    public static int pathcost(int sar , int tah) {
        int node = 1000;
        Graph graph = new Graph(node);
        for (int i = 0; i < alldata.size(); i++) {
            int[] qqq = alldata.get(i);
            int source = (qqq[0]);
            int dest = (qqq[1]);
            int weight = (qqq[2]);
            graph.addEdge(source , dest , weight);
        }
        List<Integer> shortestPath = graph.aStar(sar , tah );

        int totalCost = 0 ;
        for (int i = 0; i < shortestPath.size() - 1; i++) {
            int a = shortestPath.get(i);
            int b = shortestPath.get(i + 1);
            totalCost += graph.getEdgeWeight(a,b);
        }


        return totalCost ;

    }

    public static ArrayList<int[]> filereader() throws FileNotFoundException {
        String filePath = "alldata.txt";
        File file = new File(filePath);
        Scanner raeder = new Scanner(file);
        String[] firstline = raeder.nextLine().split(" ");
        int mline = 963;
        ArrayList<int[]> filearray = new ArrayList<int[]>();
        for (int i = 0; i < mline; i++) {
            int[] aaa = new int[7];
            String[] lines = raeder.nextLine().split(" ");
            aaa[0] = Integer.parseInt(lines[0]);
            aaa[1] = Integer.parseInt(lines[1]);
            aaa[2] = Integer.parseInt(lines[2]);
            aaa[3] = Integer.parseInt(lines[3]);
            aaa[4] = Integer.parseInt(lines[4]);
            aaa[5] = Integer.parseInt(lines[5]);
            aaa[6] = Integer.parseInt(lines[6]);
            double tedadcar = (Math.random()*1000);
            double toolmasir = aaa[2]*1000;
            double traffic = toolmasir/tedadcar;
            aaa[2] = (int)traffic ;
            filearray.add(aaa);
        }
        return filearray;
    }

    public void printpath(ArrayList<int[]> pathes) {
        for (int i = 0; i < 20; i++) {
            int[] a = pathes.get(i);
            System.out.println(a[0]+"  "+a[1]+"  "+a[2]+"  "+a[3]+"  "+a[4]+"  "+a[5]+"  "+a[6]+"  ");
        }
    }

    public void drawsecondshortpath(int sar , int tah , ArrayList<int[]> pathes , int thickness,PixelWriter pixelWriter) {
        List<Integer> shortestPath = path(sar,tah,pathes);
        for (int i = 0; i < shortestPath.size()-1; i++) {

            int a = shortestPath.get(i);
            int b = shortestPath.get(i+1);
            for (int j = 0; j < pathes.size(); j++) {
                int[] masir = pathes.get(j);
                if(((masir[0]==a)&&(masir[1]==b))||((masir[0]==b)&&(masir[1]==a)))
                {
                    int toolmasir = masir[2];
                    if (toolmasir<75)
                    {
                        drawLine(pixelWriter,masir[3],masir[4],masir[5],masir[6],level1traffic2,thickness);
                    }
                    if ((toolmasir>=75)&&(toolmasir<150))
                    {
                        drawLine(pixelWriter,masir[3],masir[4],masir[5],masir[6],level2traffic2,thickness);
                    }
                    if ((toolmasir>=150)&&(toolmasir<225))
                    {
                        drawLine(pixelWriter,masir[3],masir[4],masir[5],masir[6],level3traffic2,thickness);
                    }
                    if (toolmasir>=225)
                    {
                        drawLine(pixelWriter,masir[3],masir[4],masir[5],masir[6],level4traffic2,thickness);
                    }


                    break;
                }
            }

        }
    }

    public int deletepathnum(int sar , int tah , ArrayList<int[]> pathes) {
        for (int i = 0; i < pathes.size(); i++) {
            int[] p = pathes.get(i);
            if (((p[0]==sar)&&(p[1]==tah))||((p[1]==sar)&&(p[0]==tah)))
            {
                return i;
            }
        }
        return -1;
    }

    public ArrayList<int[]> removepath( ArrayList<int[]>pathes , ArrayList<Integer>removed) {
        ArrayList<int[]> ret = new ArrayList();
        int count = 0 ;
        for (int i = 0; i < pathes.size(); i++) {
            if (i!=removed.get(count))
            {
                ret.add(pathes.get(i));
            }
            else
            {
                if(count<removed.size()-1)
                {
                    count++;
                }

            }
        }

        return ret;

    }

    public void drawlogo(int x1,int y1 , int x2 , int y2 ,PixelWriter pixelWriter) {
        PixelReader pixelReader = imagelogo.getPixelReader();
        int imageWidth = (int) imagelogo.getWidth();
        int imageHeight = (int) imagelogo.getHeight();

        for (int x = 0; x < imageWidth; x++) {
            for (int y = 0; y < imageHeight; y++) {
                Color color = pixelReader.getColor(x, y);
                if((color.getRed()!=0)&&(color.getBlue()!=0)&&(color.getGreen()!=0))
                {
                    pixelWriter.setColor(x1+70-x,y1 - 147 + y, color);
                    pixelWriter.setColor(x2+70-x,y2 - 147 + y, color);
                }
                }

        }

    }

    public void drawpathes(int sar , int tah , ArrayList<int[]> pathes , int thickness,PixelWriter pixelWriter) {
            ArrayList<Integer> havetoremove = new ArrayList<Integer>();
            List<Integer> shortestPath = path(sar,tah,pathes);
            int x1 = 0,x2=0,y1=0,y2=0;
            for (int i = 0; i < shortestPath.size()-1; i++) {

                int a = shortestPath.get(i);
                int b = shortestPath.get(i+1);

                for (int j = 0; j < pathes.size(); j++) {
                    int[] masir = pathes.get(j);
                    if(((masir[0]==a)&&(masir[1]==b))||((masir[0]==b)&&(masir[1]==a)))
                    {
                        if(i==0)
                        {
                            if(masir[0]==sar)
                            {

                                x1 = masir[3];
                                y1 = masir[4];
                            }
                            else
                            {

                                x1 = masir[5];
                                y1 = masir[6];
                            }

                        }
                        if(i==shortestPath.size()-2)
                        {
                            if(masir[0]==tah)
                            {

                                x2 = masir[3];
                                y2 = masir[4];
                            }
                            else
                            {

                                x2 = masir[5];
                                y2 = masir[6];
                            }
                        }


                        int toolmasir = masir[2];
                        if (toolmasir<75)
                        {
                            drawLine(pixelWriter,masir[3],masir[4],masir[5],masir[6],level1traffic,thickness);
                        }
                        if ((toolmasir>=75)&&(toolmasir<150))
                        {
                            drawLine(pixelWriter,masir[3],masir[4],masir[5],masir[6],level2traffic,thickness);
                        }
                        if ((toolmasir>=150)&&(toolmasir<225))
                        {
                            drawLine(pixelWriter,masir[3],masir[4],masir[5],masir[6],level3traffic,thickness);
                        }
                        if (toolmasir>=225)
                        {
                            drawLine(pixelWriter,masir[3],masir[4],masir[5],masir[6],level4traffic,thickness);
                        }


                        break;
                    }
                }
                int d = deletepathnum(a,b,pathes);
                havetoremove.add(d);
            }
            drawlogo(x1,y1,x2,y2,pixelWriter);
            drawsecondshortpath(sar,tah,removepath(pathes,havetoremove),15,pixelWriter);
        }

    public void drawallpathes(ArrayList<int[]> pathes,PixelWriter pixelWriter) {

        for (int i = 0; i < pathes.size(); i++) {
            int[] p = pathes.get(i);
            drawLine(pixelWriter,p[3],p[4],p[5],p[6],Color.BLACK,3);
        }

    }

    public void setLocation(int start, int end) {
        this.start = start;
        this.end = end;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Image image = new Image(getClass().getResource("/mappiccrop.jpg").toExternalForm());
        PixelReader pixelReader = image.getPixelReader();
        int width = (int) image.getWidth();
        int height = (int) image.getHeight();
        WritableImage writableImage = new WritableImage(pixelReader, width, height);
        imageView = new ImageView(writableImage);
        PixelWriter pixelWriter = writableImage.getPixelWriter();
        imageView.setPreserveRatio(true);

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(imageView);
        scrollPane.setPannable(true);
        scrollPane.setFitToWidth(true);
        scrollPane.setFitToHeight(true);

        scrollPane.addEventFilter(ScrollEvent.ANY, event -> {
            if (event.getDeltaY() < 0) {
                zoomOut();
            } else {
                zoomIn();
            }
            event.consume();
        });
        StackPane root = new StackPane(scrollPane);
        root.setAlignment(Pos.CENTER);
        Scene scene = new Scene(root, 600,600);
//موس
//        imageView.setOnMouseClicked(new EventHandler<MouseEvent>() {
//            @Override
//            public void handle(MouseEvent event)
//            {
//                int[] array = new int[7] ;
//                double imageX = event.getX();
//                double imageY = event.getY();
//                int[] newpoint = {(int) imageX, (int) imageY};
//                int num = shomarenode(imageX, imageY);
//                if(num==-1)
//                {
//                    allpoint.add(newpoint);
//                }
//                else
//                {
//                    tedadtekrar++;
//                }
//
//                for (int y = 0; y < height; y++) {
//                    for (int x = 0; x < width; x++) {
//                        double distance = Math.sqrt(Math.pow(x - imageX, 2) + Math.pow(y - imageY, 2));
//                        if (distance <= 10) {
//                            pixelWriter.setColor(x, y, Color.RED);
//                        }
//                    }
//                }
//                tedadclick++;
//                if(num==-1)
//                {
//                    num = allpoint.size()-1;
//                }
//                if(tedadclick%2==1)
//                {
//                    //System.out.println("p1");
//                    pointx1=imageX;
//                    pointy1=imageY;
//                    num1 = num;
//                }
//                else
//                {
//                    //System.out.println("p2");
//                    pointx2 = imageX;
//                    pointy2 = imageY;
//                    num2 = num;
//                    array[0]= num1;
//                    array[1]= num2;
//                    array[2]= distancetwopoint(pointx1,pointy1,pointx2,pointy2);
//                    array[3]= (int) pointx1;
//                    array[4]= (int) pointy1;
//                    array[5]= (int) pointx2;
//                    array[6]= (int) pointy2;
//                    //drawLine(pixelWriter, (int) pointx1, (int) pointy1, (int) pointx2, (int) pointy2,Color.RED,7);
//
//                    //line
////                    String line = "";
////                    for (int i = 0; i < 7; i++) {
////                        line+=array[i]+" ";
////                    }
////                    System.out.println(line);
//                    //appendTextToFile("alldata.txt", line);
//
//
//                }
//
//
//
//            }
//
//
//        });
        //draw path

        drawpathes(start,end,alldata,15,pixelWriter);
        //drawallpathes(alldata,pixelWriter);

        primaryStage.setScene(scene);
        primaryStage.setTitle("MAP");
        primaryStage.show();
        scrollPane.setHvalue(.5);
        scrollPane.setVvalue(.5);
        imageView.setScaleY(.3);
        imageView.setScaleX(.3);
    }
    private void zoomIn() {
        if (scaleFactor < MAX_SCALE) {
            scaleFactor *= ZOOM_FACTOR;
            imageView.setScaleX(scaleFactor);
            imageView.setScaleY(scaleFactor);
        }
    }

    public int distancetwopoint (double x1 , double y1 , double x2 , double y2) {
        double dx = x1 - x2;
        double dy = y1 - y2;
        return (int)Math.sqrt(dx * dx + dy * dy);
    }

    public void appendTextToFile(String fileName, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true))) {
            writer.write(content + "\n");
        } catch (IOException e) {
            System.err.println("An error occurred: " + e.getMessage());
        }
    }

    public int shomarenode (double x , double y) {

        for (int i = 0; i <allpoint.size(); i++) {
            int[] point = allpoint.get(i);
            double dx = point[0]-x;
            double dy = point[1]-y;
            double dis = Math.sqrt(dx * dx + dy * dy);

            if (dis <10)
            {
                return i ;
            }
        }
        return -1 ;
    }

    private void zoomOut() {
        if (scaleFactor > MIN_SCALE) {
            scaleFactor /= ZOOM_FACTOR;
            imageView.setScaleX(scaleFactor);
            imageView.setScaleY(scaleFactor);
        }
    }

    private void drawLine(PixelWriter pixelWriter, int x1, int y1, int x2, int y2, Color color, int thickness) {
        int deltaX = Math.abs(x2 - x1);
        int deltaY = Math.abs(y2 - y1);
        int error = deltaX - deltaY;
        int x = x1;
        int y = y1;

        int xDirection = (x2 > x1) ? 1 : -1;
        int yDirection = (y2 > y1) ? 1 : -1;

        int thicknessOffsetX = 0;
        int thicknessOffsetY = 0;

        if (deltaX > deltaY) {
            thicknessOffsetY = thickness / 2;
        } else {
            thicknessOffsetX = thickness / 2;
        }

        while (x != x2 || y != y2) {
            for (int i = -thicknessOffsetX; i <= thicknessOffsetX; i++) {
                for (int j = -thicknessOffsetY; j <= thicknessOffsetY; j++) {
                    pixelWriter.setColor(x + i, y + j, color);
                }
            }

            int error2 = error * 2;

            if (error2 > -deltaY) {
                error -= deltaY;
                x += xDirection;
            }
            if (error2 < deltaX) {
                error += deltaX;
                y += yDirection;
            }
        }
    }


}

