package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.Costumer;
import logic.Owner;
import logic.Restaurant;
import logic.Server;

public class DeliveryOrder extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/delivery.jpg").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        anchorPane.setPrefWidth(640);
        anchorPane.setPrefHeight(360);


        Button confirm = new Button("Confirm"), back = new Button("BACK"), path = new Button("Show Path");

        TextField location = new TextField(), cost = new TextField(Double.toString(Costumer.cartPrice(Costumer.loggedInCostumer.cart)));

        location.setPromptText("Location: ");
        cost.setEditable(false);

        confirm.setLayoutX(520);
        confirm.setLayoutY(90);
        confirm.setPrefWidth(60);
        confirm.setPrefHeight(25);

        path.setLayoutX(390);
        path.setLayoutY(15);
        path.setPrefWidth(72);
        path.setPrefHeight(25);

        back.setLayoutX(15);
        back.setLayoutY(320);
        back.setPrefWidth(45);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        location.setLayoutX(475);
        location.setLayoutY(15);
        location.setPrefWidth(150);
        location.setPrefHeight(25);

        cost.setLayoutX(475);
        cost.setLayoutY(50);
        cost.setPrefWidth(150);
        cost.setPrefHeight(25);

        anchorPane.getChildren().addAll(confirm, path, back, location, cost);

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new Cart().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        path.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Map map = new Map();
                System.out.println(Restaurant.getRestaurants().get(Costumer.loggedInCostumer.cart.get(0).restaurantId - 1).location);
                map.setLocation(Restaurant.getRestaurants().get(Costumer.loggedInCostumer.cart.get(0).restaurantId - 1).location, Integer.parseInt(location.getText()));
                try {
                    map.start(new Stage());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        confirm.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Costumer.loggedInCostumer.location = Integer.parseInt(location.getText());
                Costumer.confirmOrder();

                try {
                    new CostumerRestaurantList().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });


        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        Main.stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());

                confirm.setLayoutX(520 * Main.stage.getScene().getWidth() / 640);
                confirm.setPrefWidth(60 * Main.stage.getScene().getWidth() / 640);

                path.setLayoutX(390 * Main.stage.getScene().getWidth() / 640);
                path.setPrefWidth(72 * Main.stage.getScene().getWidth() / 640);

                back.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                back.setPrefWidth(45 * Main.stage.getScene().getWidth() / 640);

                location.setLayoutX(475 * Main.stage.getScene().getWidth() / 640);
                location.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);

                cost.setLayoutX(475 * Main.stage.getScene().getWidth() / 640);
                cost.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);

            }
        });

        Main.stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());

                confirm.setLayoutY(90 * Main.stage.getScene().getHeight() / 360);
                confirm.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                path.setLayoutY(15 * Main.stage.getScene().getHeight() / 360);
                path.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                back.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                back.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                location.setLayoutY(15 * Main.stage.getScene().getHeight() / 360);
                location.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                cost.setLayoutY(50 * Main.stage.getScene().getHeight() / 360);
                cost.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

            }
        });

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });

    }


}
