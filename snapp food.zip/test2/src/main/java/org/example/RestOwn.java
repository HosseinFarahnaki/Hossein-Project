package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.*;

import java.net.URL;

public class RestOwn extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/menu.jpg").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        anchorPane.setPrefWidth(640);
        anchorPane.setPrefHeight(360);

        TextField name = new TextField(Owner.loggedInOwner.selectedRestaurant.name), location = new TextField(Integer.toString(Owner.loggedInOwner.selectedRestaurant.location)), type = new TextField(Owner.loggedInOwner.selectedRestaurant.foodType);
        TextField foodname = new TextField(), price = new TextField();

        Button aplly = new Button("APPLY"), back = new Button("BACK"), add = new Button("ADD");
        VBox vBox, commnets;
        ImageView image = new ImageView(getClass().getResource("/menuu.jpg").toExternalForm());
        ImageView image5 = new ImageView(getClass().getResource("/history.png").toExternalForm());

        Text inf = new Text("Information"), n = new Text("Add New Food");

        ListView<String> l = Restaurant.getOwnMenu();
        ListView<String> l1 = Restaurant.getOwnComments();


        name.setLayoutX(15);
        name.setLayoutY(55);
        name.setPrefWidth(150);
        name.setPrefHeight(25);
        name.setEditable(false);

        location.setLayoutX(15);
        location.setLayoutY(90);
        location.setPrefWidth(150);
        location.setPrefHeight(25);

        type.setLayoutX(15);
        type.setLayoutY(125);
        type.setPrefWidth(150);
        type.setPrefHeight(25);

        aplly.setLayoutX(62);
        aplly.setLayoutY(195);
        aplly.setPrefWidth(55);
        aplly.setPrefHeight(25);

        back.setLayoutX(15);
        back.setLayoutY(320);
        back.setPrefWidth(45);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        image.setLayoutX(385);
        image.setLayoutY(0);
        image.setFitWidth(255);
        image.setFitHeight(360);
        image.setPreserveRatio(false);

        image5.setLayoutX(5);
        image5.setLayoutY(185);
        image5.setFitWidth(30);
        image5.setFitHeight(30);
        image5.setPreserveRatio(false);

        foodname.setLayoutX(190);
        foodname.setLayoutY(55);
        foodname.setPrefWidth(150);
        foodname.setPrefHeight(25);

        price.setLayoutX(190);
        price.setLayoutY(90);
        price.setPrefWidth(150);
        price.setPrefHeight(25);

        add.setLayoutX(240);
        add.setLayoutY(195);
        add.setPrefWidth(55);
        add.setPrefHeight(25);

        inf.setLayoutX(35);
        inf.setLayoutY(40);
        inf.setFont(Font.font(20));

        n.setLayoutX(200);
        n.setLayoutY(40);
        n.setFont(Font.font(20));

        anchorPane.getChildren().addAll(name, location, type, aplly, back, image, foodname, price, add, inf, n, image5);

        aplly.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Apply Changes");
                alert.setContentText("Are you Sure ?");
                alert.showAndWait();

                Owner.editLocation(Integer.parseInt(location.getText()));
                Owner.editFoodType(type.getText());
            }
        });

        add.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Owner.addNewFood(foodname.getText(), Double.parseDouble(price.getText()));
                for (int i = 0; i < Owner.loggedInOwner.selectedRestaurant.menu.size(); i++) {
                    System.out.println(Owner.loggedInOwner.selectedRestaurant.menu.get(i).name);
                }
                l.getItems().add(Restaurant.getOwnMenu().getItems().get(Restaurant.getOwnMenu().getItems().size() - 1));
            }
        });

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Owner.loggedInOwner.selectedRestaurant = null;
                try {
                    new OwnerRestaurantList().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        image5.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new History().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        l.setOnMouseClicked(mouseEvent -> {
            ObservableList<String> observableList = l.getSelectionModel().getSelectedItems();
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < observableList.size(); i++) {
                s.append(observableList.get(i));
            }
            String ss = s.toString();
            String[] sss = ss.split(" ");

            Owner.selectFood(Integer.parseInt(sss[0]));

            try {
                new OwnFood().start(Main.stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        });

        vBox = new VBox(l);
        vBox.setLayoutX(385);
        vBox.setLayoutY(55);
        vBox.setPrefWidth(170);
        vBox.setPrefHeight(290);

        commnets = new VBox(l1);
        commnets.setLayoutX(90);
        commnets.setLayoutY(245);
        commnets.setPrefWidth(255);
        commnets.setPrefHeight(100);
        anchorPane.getChildren().addAll(vBox, commnets);

        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        Main.stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());

                name.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                name.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);

                location.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                location.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);


                type.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                type.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);

                aplly.setLayoutX(62 * Main.stage.getScene().getWidth() / 640);
                aplly.setPrefWidth(55 * Main.stage.getScene().getWidth() / 640);

                back.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                back.setPrefWidth(45 * Main.stage.getScene().getWidth() / 640);

                image.setLayoutX(385 * Main.stage.getScene().getWidth() / 640);
                image.setFitWidth(255 * Main.stage.getScene().getWidth() / 640);

                image5.setLayoutX(5 * Main.stage.getScene().getWidth() / 640);
                image5.setFitWidth(30 * Main.stage.getScene().getWidth() / 640);

                foodname.setLayoutX(190 * Main.stage.getScene().getWidth() / 640);
                foodname.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);

                price.setLayoutX(190 * Main.stage.getScene().getWidth() / 640);
                price.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);

                add.setLayoutX(240 * Main.stage.getScene().getWidth() / 640);
                add.setPrefWidth(55 * Main.stage.getScene().getWidth() / 640);

                inf.setLayoutX(35 * Main.stage.getScene().getWidth() / 640);
                inf.setFont(Font.font((int)(20 * Main.stage.getScene().getWidth() / 640)));

                n.setLayoutX(200 * Main.stage.getScene().getWidth() / 640);
                n.setFont(Font.font((int)(20 * Main.stage.getScene().getWidth() / 640)));

                vBox.setLayoutX(385 * Main.stage.getScene().getWidth() / 640);
                vBox.setPrefWidth(170 * Main.stage.getScene().getWidth() / 640);

                commnets.setLayoutX(90 * Main.stage.getScene().getWidth() / 640);
                commnets.setPrefWidth(255 * Main.stage.getScene().getWidth() / 640);


            }
        });

        Main.stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());

                name.setLayoutY(55 * Main.stage.getScene().getHeight() / 360);
                name.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                location.setLayoutY(90 * Main.stage.getScene().getHeight() / 360);
                location.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                type.setLayoutY(125 * Main.stage.getScene().getHeight() / 360);
                type.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                aplly.setLayoutY(195 * Main.stage.getScene().getHeight() / 360);
                aplly.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                back.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                back.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                image.setLayoutY(0);
                image.setFitHeight(360 * Main.stage.getScene().getHeight() / 360);

                image5.setLayoutY(185 * Main.stage.getScene().getHeight() / 360);
                image5.setFitHeight(30 * Main.stage.getScene().getHeight() / 360);

                foodname.setLayoutY(55 * Main.stage.getScene().getHeight() / 360);
                foodname.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                price.setLayoutY(90 * Main.stage.getScene().getHeight() / 360);
                price.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                add.setLayoutY(195 * Main.stage.getScene().getHeight() / 360);
                add.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                inf.setLayoutY(40 * Main.stage.getScene().getHeight() / 360);
                inf.setFont(Font.font((int)(20 * Main.stage.getScene().getHeight() / 360)));

                n.setLayoutY(40 * Main.stage.getScene().getHeight() / 360);
                n.setFont(Font.font((int)(20 * Main.stage.getScene().getHeight() / 360)));

                vBox.setLayoutY(55 * Main.stage.getScene().getHeight() / 360);
                vBox.setPrefHeight(290 * Main.stage.getScene().getHeight() / 360);

                commnets.setLayoutY(245 * Main.stage.getScene().getHeight() / 360);
                commnets.setPrefHeight(100 * Main.stage.getScene().getHeight() / 360);
            }
        });

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });

    }

}
