package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.Costumer;
import logic.Owner;
import logic.Server;

import java.net.URL;

public class Login extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        URL url = Main.class.getResource("/FXML/login.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/login.jpeg").toExternalForm()))));

        Button back = new Button("BACK");

        back.setLayoutX(15);
        back.setLayoutY(320);
        back.setPrefWidth(45);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        anchorPane.getChildren().add(back);

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new Main().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        Main.stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());
                TextField textField1 = (TextField) anchorPane.getChildren().get(0);
                PasswordField textField2 = (PasswordField) anchorPane.getChildren().get(4);

                Button button1 = (Button) anchorPane.getChildren().get(2);
                Button button2 = (Button) anchorPane.getChildren().get(3);

                RadioButton checkBox1 = (RadioButton) anchorPane.getChildren().get(5);
                RadioButton checkBox2 = (RadioButton) anchorPane.getChildren().get(6);

                ImageView imageView = (ImageView) anchorPane.getChildren().get(1);
                imageView.setLayoutX(150 * Main.stage.getScene().getWidth() / 640);
                imageView.setFitWidth(300 * Main.stage.getScene().getWidth() / 640);

                back.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                back.setPrefWidth(45 * Main.stage.getScene().getWidth() / 640);

                button1.setPrefWidth(43 * Main.stage.getScene().getWidth() / 640);
                button1.setLayoutX(247 * Main.stage.getScene().getWidth() / 640);

                button2.setPrefWidth(48 * Main.stage.getScene().getWidth() / 640);
                button2.setLayoutX(320 * Main.stage.getScene().getWidth() / 640);

                textField1.setPrefWidth(200 * Main.stage.getScene().getWidth() / 640);
                textField1.setLayoutX(200 * Main.stage.getScene().getWidth() / 640);

                textField2.setPrefWidth(200 * Main.stage.getScene().getWidth() / 640);
                textField2.setLayoutX(200 * Main.stage.getScene().getWidth() / 640);

                checkBox1.setPrefWidth(73 * Main.stage.getScene().getWidth() / 640);
                checkBox1.setLayoutX(215 * Main.stage.getScene().getWidth() / 640);

                checkBox2.setPrefWidth(57 * Main.stage.getScene().getWidth() / 640);
                checkBox2.setLayoutX(340 * Main.stage.getScene().getWidth() / 640);
            }
        });

        Main.stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());
                TextField textField1 = (TextField) anchorPane.getChildren().get(0);
                PasswordField textField2 = (PasswordField) anchorPane.getChildren().get(4);

                Button button1 = (Button) anchorPane.getChildren().get(2);
                Button button2 = (Button) anchorPane.getChildren().get(3);

                RadioButton checkBox1 = (RadioButton) anchorPane.getChildren().get(5);
                RadioButton checkBox2 = (RadioButton) anchorPane.getChildren().get(6);

                ImageView imageView = (ImageView) anchorPane.getChildren().get(1);
                imageView.setLayoutY(75 * Main.stage.getScene().getHeight() / 360);
                imageView.setFitHeight(60 * Main.stage.getScene().getHeight() / 360);

                back.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                back.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                button1.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                button1.setLayoutY(220 * Main.stage.getScene().getHeight() / 360);

                button2.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                button2.setLayoutY(220 * Main.stage.getScene().getHeight() / 360);

                textField1.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                textField1.setLayoutY(145 * Main.stage.getScene().getHeight() / 360);

                textField2.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                textField2.setLayoutY(180 * Main.stage.getScene().getHeight() / 360);

                checkBox1.setPrefHeight(17 * Main.stage.getScene().getHeight() / 360);
                checkBox1.setLayoutY(260 * Main.stage.getScene().getHeight() / 360);

                checkBox2.setPrefHeight(17 * Main.stage.getScene().getHeight() / 360);
                checkBox2.setLayoutY(260 * Main.stage.getScene().getHeight() / 360);
            }
        });

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });
    }
}
