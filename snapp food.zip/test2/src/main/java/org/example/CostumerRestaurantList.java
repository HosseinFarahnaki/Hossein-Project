package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.*;

public class CostumerRestaurantList extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/rest2.png").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        anchorPane.setPrefWidth(640);
        anchorPane.setPrefHeight(360);

        VBox FAST, IRANI, OTHERS, recum;

        TextField search = new TextField();

        ImageView image = new ImageView(getClass().getResource("/search.png").toExternalForm());
        ImageView plus = new ImageView(getClass().getResource("/rest.png").toExternalForm());
        ImageView image3 = new ImageView(getClass().getResource("/cart.png").toExternalForm());
        ImageView image4 = new ImageView(getClass().getResource("/setting.png").toExternalForm());
        ImageView image5 = new ImageView(getClass().getResource("/history.png").toExternalForm());

        Text T1 = new Text("FAST FOOD"), T2 = new Text("IRANI"), T3 = new Text("OTHERS"), T4 = new Text("RECOMMENDATION");

        ListView<String> l1 = Restaurant.getFast(search.getText());
        ListView<String> l2 = Restaurant.getIrani(search.getText());
        ListView<String> l3 = Restaurant.getOthers(search.getText());
        ListView<String> l4 = Costumer.recum();

        Button back = new Button("BACK");

        search.setLayoutX(35);
        search.setLayoutY(0);
        search.setPrefWidth(605);
        search.setPrefHeight(25);

        image.setLayoutX(0);
        image.setLayoutY(0);
        image.setFitWidth(25);
        image.setFitHeight(25);
        image.setPreserveRatio(false);

        plus.setLayoutX(0);
        plus.setLayoutY(150);
        plus.setFitWidth(280);
        plus.setFitHeight(210);
        plus.setPreserveRatio(false);

        image3.setLayoutX(0);
        image3.setLayoutY(40);
        image3.setFitWidth(30);
        image3.setFitHeight(30);
        image3.setPreserveRatio(false);

        image4.setLayoutX(0);
        image4.setLayoutY(90);
        image4.setFitWidth(35);
        image4.setFitHeight(35);
        image4.setPreserveRatio(false);

        image5.setLayoutX(0);
        image5.setLayoutY(135);
        image5.setFitWidth(30);
        image5.setFitHeight(30);
        image5.setPreserveRatio(false);

        T1.setLayoutX(290);
        T1.setLayoutY(55);
        T1.setFill(Paint.valueOf("ffffff"));

        T2.setLayoutX(435);
        T2.setLayoutY(55);
        T2.setFill(Paint.valueOf("ffffff"));

        T3.setLayoutX(560);
        T3.setLayoutY(55);
        T3.setFill(Paint.valueOf("ffffff"));

        T4.setLayoutX(85);
        T4.setLayoutY(55);
        T4.setFill(Paint.valueOf("ffffff"));

        back.setLayoutX(15);
        back.setLayoutY(320);
        back.setPrefWidth(45);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        anchorPane.getChildren().addAll(search, image, T1, T2, T3, T4, plus, image3, back, image4, image5);

        l1.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        l2.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        l3.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        l4.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        FAST = new VBox(l1);
        FAST.setLayoutX(260);
        FAST.setLayoutY(80);
        FAST.setPrefWidth(120);
        FAST.setPrefHeight(280);

        IRANI = new VBox(l2);
        IRANI.setLayoutX(390);
        IRANI.setLayoutY(80);
        IRANI.setPrefWidth(120);
        IRANI.setPrefHeight(280);

        OTHERS = new VBox(l3);
        OTHERS.setLayoutX(520);
        OTHERS.setLayoutY(80);
        OTHERS.setPrefWidth(120);
        OTHERS.setPrefHeight(280);

        l4.setBackground(new Background(new BackgroundFill(Paint.valueOf("ff0000"),null,null)));

        recum = new VBox(l4);
        recum.setLayoutX(60);
        recum.setLayoutY(80);
        recum.setPrefWidth(160);
        recum.setPrefHeight(70);


        anchorPane.getChildren().addAll(FAST, IRANI, OTHERS, recum);

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Costumer.logoutCostumer();
                try {
                    new Main().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        search.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
                l1.getItems().clear();
                l2.getItems().clear();
                l3.getItems().clear();

                ListView<String> l11 = Restaurant.getFast(search.getText());
                ListView<String> l22 = Restaurant.getIrani(search.getText());
                ListView<String> l33 = Restaurant.getOthers(search.getText());

                for (int i = 0; i < l11.getItems().size(); i++) {
                    l1.getItems().add(l11.getItems().get(i));
                }
                for (int i = 0; i < l22.getItems().size(); i++) {
                    l2.getItems().add(l22.getItems().get(i));
                }
                for (int i = 0; i < l33.getItems().size(); i++) {
                    l3.getItems().add(l33.getItems().get(i));
                }
            }
        });

        image3.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new Cart().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        image4.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {

                Stage d = new Stage();
                AnchorPane dd = new AnchorPane();
                dd.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/settingBack.jpg").toExternalForm()))));

                Scene scene = new Scene(dd);
                dd.setPrefWidth(300);
                dd.setPrefHeight(420);

                TextField cash = new TextField(Double.toString(Costumer.loggedInCostumer.cash)), increase = new TextField();
                cash.setEditable(false);
                increase.setPromptText("Amount: ");

                ImageView wallet = new ImageView(getClass().getResource("/wallet.png").toExternalForm());
                ImageView plus = new ImageView(getClass().getResource("/plus.png").toExternalForm());

                Button theme = new Button("Theme");

                cash.setLayoutX(75);
                cash.setLayoutY(40);
                cash.setPrefWidth(150);
                cash.setPrefHeight(25);

                increase.setLayoutX(75);
                increase.setLayoutY(90);
                increase.setPrefWidth(150);
                increase.setPrefHeight(25);


                theme.setLayoutX(125);
                theme.setLayoutY(370);
                theme.setPrefWidth(52);
                theme.setPrefHeight(25);

                wallet.setLayoutX(15);
                wallet.setLayoutY(30);
                wallet.setFitWidth(40);
                wallet.setFitHeight(40);
                wallet.setPreserveRatio(false);

                plus.setLayoutX(20);
                plus.setLayoutY(85);
                plus.setFitWidth(35);
                plus.setFitHeight(35);
                plus.setPreserveRatio(false);

                dd.getChildren().addAll(cash, increase, theme, wallet, plus);

                plus.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        Costumer.chargeAccount(Double.parseDouble(increase.getText()));
                        increase.setText("");
                        cash.setText(Double.toString(Costumer.loggedInCostumer.cash));
                    }
                });

                theme.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        if(Main.changeTheme)
                            Main.changeTheme = false;
                        else
                            Main.changeTheme = true;
                        try {
                            new CostumerRestaurantList().start(Main.stage);
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }
                });


                d.setScene(scene);
                d.show();

            }
        });

        image5.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new History().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });


        l1.setOnMouseClicked(mouseEvent -> {
            ObservableList<String> observableList = l1.getSelectionModel().getSelectedItems();
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < observableList.size(); i++) {
                s.append(observableList.get(i));
            }
            String ss = s.toString();
            String[] sss = ss.split(" ");

            Costumer.selectRestaurant(Integer.parseInt(sss[0]));

            try {
                new RestMenu().start(Main.stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        });

        l2.setOnMouseClicked(mouseEvent -> {
            ObservableList<String> observableList = l2.getSelectionModel().getSelectedItems();
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < observableList.size(); i++) {
                s.append(observableList.get(i));
            }
            String ss = s.toString();
            String[] sss = ss.split(" ");

            Costumer.selectRestaurant(Integer.parseInt(sss[0]));
            try {
                new RestMenu().start(Main.stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        });

        l3.setOnMouseClicked(mouseEvent -> {
            ObservableList<String> observableList = l3.getSelectionModel().getSelectedItems();
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < observableList.size(); i++) {
                s.append(observableList.get(i));
            }
            String ss = s.toString();
            String[] sss = ss.split(" ");

            Costumer.selectRestaurant(Integer.parseInt(sss[0]));
            try {
                new RestMenu().start(Main.stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        });

        l4.setOnMouseClicked(mouseEvent -> {
            ObservableList<String> observableList = l4.getSelectionModel().getSelectedItems();
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < observableList.size(); i++) {
                s.append(observableList.get(i));
            }
            String ss = s.toString();
            String[] sss = ss.split(" ");

            Costumer.selectRestaurant(Food.getFood(Integer.parseInt(sss[0])).restaurantId);
            Costumer.selectFood(Integer.parseInt(sss[0]));


            try {
                new MenuFood().start(Main.stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        });



        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        Main.stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());

                search.setLayoutX(35 * Main.stage.getScene().getWidth() / 640);
                search.setPrefWidth(605 * Main.stage.getScene().getWidth() / 640);

                back.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                back.setPrefWidth(45 * Main.stage.getScene().getWidth() / 640);

                image.setLayoutX(0);
                image.setFitWidth(25 * Main.stage.getScene().getWidth() / 640);

                plus.setLayoutX(0);
                plus.setFitWidth(280 * Main.stage.getScene().getWidth() / 640);

                image3.setLayoutX(0);
                image3.setFitWidth(30 * Main.stage.getScene().getWidth() / 640);

                image4.setLayoutX(0);
                image4.setFitWidth(35 * Main.stage.getScene().getWidth() / 640);

                image5.setLayoutX(0);
                image5.setFitWidth(30 * Main.stage.getScene().getWidth() / 640);

                T1.setLayoutX(290 * Main.stage.getScene().getWidth() / 640);
                T1.setFont(Font.font((int)(12 * Main.stage.getScene().getWidth() / 640)));

                T2.setLayoutX(435 * Main.stage.getScene().getWidth() / 640);
                T2.setFont(Font.font((int)(12 * Main.stage.getScene().getWidth() / 640)));

                T3.setLayoutX(560 * Main.stage.getScene().getWidth() / 640);
                T3.setFont(Font.font((int)(12 * Main.stage.getScene().getWidth() / 640)));

                T4.setLayoutX(85 * Main.stage.getScene().getWidth() / 640);
                T4.setFont(Font.font((int)(12 * Main.stage.getScene().getWidth() / 640)));

                FAST.setLayoutX(260 * Main.stage.getScene().getWidth() / 640);
                FAST.setPrefWidth(120 * Main.stage.getScene().getWidth() / 640);

                IRANI.setLayoutX(390 * Main.stage.getScene().getWidth() / 640);
                IRANI.setPrefWidth(120 * Main.stage.getScene().getWidth() / 640);

                OTHERS.setLayoutX(520 * Main.stage.getScene().getWidth() / 640);
                OTHERS.setPrefWidth(120 * Main.stage.getScene().getWidth() / 640);

                recum.setLayoutX(60 * Main.stage.getScene().getWidth() / 640);
                recum.setPrefWidth(160 * Main.stage.getScene().getWidth() / 640);
            }
        });

        Main.stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());

                search.setLayoutY(0);
                search.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                back.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                back.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                image.setLayoutY(0);
                image.setFitHeight(25 * Main.stage.getScene().getHeight() / 360);

                plus.setLayoutY(150 * Main.stage.getScene().getHeight() / 360);
                plus.setFitHeight(210 * Main.stage.getScene().getHeight() / 360);

                image3.setLayoutY(40 * Main.stage.getScene().getHeight() / 360);
                image3.setFitHeight(30 * Main.stage.getScene().getHeight() / 360);

                image4.setLayoutY(90 * Main.stage.getScene().getHeight() / 360);
                image4.setFitHeight(35 * Main.stage.getScene().getHeight() / 360);

                image5.setLayoutY(135 * Main.stage.getScene().getHeight() / 360);
                image5.setFitHeight(30 * Main.stage.getScene().getHeight() / 360);

                T1.setLayoutY(55 * Main.stage.getScene().getHeight() / 360);
                T1.setFont(Font.font((int)(12 * Main.stage.getScene().getHeight() / 360)));

                T2.setLayoutY(55 * Main.stage.getScene().getHeight() / 360);
                T2.setFont(Font.font((int)(12 * Main.stage.getScene().getHeight() / 360)));

                T3.setLayoutY(55 * Main.stage.getScene().getHeight() / 360);
                T3.setFont(Font.font((int)(12 * Main.stage.getScene().getHeight() / 360)));

                T4.setLayoutY(55 * Main.stage.getScene().getHeight() / 360);
                T4.setFont(Font.font((int)(12 * Main.stage.getScene().getHeight() / 360)));

                FAST.setLayoutY(80 * Main.stage.getScene().getHeight() / 360);
                FAST.setPrefHeight(280 * Main.stage.getScene().getHeight() / 360);

                IRANI.setLayoutY(80 * Main.stage.getScene().getHeight() / 360);
                IRANI.setPrefHeight(280 * Main.stage.getScene().getHeight() / 360);

                OTHERS.setLayoutY(80 * Main.stage.getScene().getHeight() / 360);
                OTHERS.setPrefHeight(280 * Main.stage.getScene().getHeight() / 360);

                recum.setLayoutY(80 * Main.stage.getScene().getHeight() / 360);
                recum.setPrefHeight(70 * Main.stage.getScene().getHeight() / 360);
            }
        });

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });

    }
}