package org.example;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Duration;
import logic.*;

public class History extends Application {
    private static final long ONE_SECOND = 1000;
    private static final long SECONDS_IN_MINUTE = 60;

    private long endTime;
    private Label timerLabel;

    private static boolean c = false;

    @Override
    public void start(Stage stage) throws Exception {
        c = false;
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/order.jpg").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        anchorPane.setPrefWidth(640);
        anchorPane.setPrefHeight(360);

        Button back = new Button("BACK");
        VBox ongoing, old;

        Text on = new Text("Ongoing Order"), off = new Text("History");
        ListView<String> l1, l2;

        if(Costumer.loggedInCostumer != null) {
            l1 = Costumer.getOngoingOrder();
            l2 = Costumer.getHistoryOrder();
        }

        else {
            l1 = Restaurant.getOngoingOrder();
            l2 = new ListView<>();
        }

        long currentTime = System.currentTimeMillis() / 1000; // Get current time in seconds
        int duration = 0;

        if(Costumer.loggedInCostumer != null)
            if(Costumer.loggedInCostumer.orders.size() > 0)
                duration = (int) (.005 * Map.pathcost(Costumer.loggedInCostumer.location, Costumer.loggedInCostumer.orders.get(Costumer.loggedInCostumer.orders.size() - 1).restaurantLocation)); // Set the duration in seconds

        endTime = currentTime + duration; // Calculate the end time

        timerLabel = new Label();
        timerLabel.setStyle("-fx-font-size: 48px; -fx-text-fill: #ffffff");
        timerLabel.setLayoutX(430);
        timerLabel.setLayoutY(50);



        if(Costumer.loggedInCostumer != null) {
            if (Costumer.loggedInCostumer.orders.size() > 0) {
                Timeline timeline = new Timeline(
                        new KeyFrame(Duration.millis(ONE_SECOND), event -> {
                            try {
                                updateTimer();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }));
                timeline.setCycleCount(Timeline.INDEFINITE);
                timeline.play();
            }
        }




        back.setLayoutX(0);
        back.setLayoutY(333);
        back.setPrefWidth(45);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if(Costumer.loggedInCostumer != null) {
                    try {
                        new CostumerRestaurantList().start(Main.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
                else {
                    try {
                        new RestOwn().start(Main.stage);
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        });

        l1.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);


        l2.setOnMouseClicked(mouseEvent -> {
                if(Costumer.loggedInCostumer != null) {
                    ObservableList<String> observableList = l2.getSelectionModel().getSelectedItems();
                    StringBuilder s = new StringBuilder();

                    for (int i = 0; i < observableList.size(); i++) {
                        s.append(observableList.get(i));
                    }

                    String ss = s.toString();
                    String[] sss = ss.split(" ");

                    Costumer.selectRestaurant(Food.getFood(Integer.parseInt(sss[0])).restaurantId);
                    Costumer.loggedInCostumer.selectedFood = Food.getFood(Integer.parseInt(sss[0]));

                    try {
                        new CommentOrder().start(new Stage());
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
        });

        ongoing = new VBox(l1);
        ongoing.setLayoutX(25);
        ongoing.setLayoutY(60);
        ongoing.setPrefWidth(300);
        ongoing.setPrefHeight(100);

        old = new VBox(l2);
        old.setLayoutX(25);
        old.setLayoutY(230);
        old.setPrefWidth(300);
        old.setPrefHeight(100);

        on.setLayoutX(105);
        on.setLayoutY(35);
        on.setFont(Font.font(20));
        on.setFill(Paint.valueOf("ffffff"));

        off.setLayoutX(140);
        off.setLayoutY(205);
        off.setFont(Font.font(20));
        off.setFill(Paint.valueOf("ffffff"));

        anchorPane.getChildren().addAll(ongoing, on, back);

        if(Costumer.loggedInCostumer != null) {
            anchorPane.getChildren().addAll(old, off);
            if(Costumer.loggedInCostumer.orders.size() > 0)
                anchorPane.getChildren().add(timerLabel);
        }

        Scene scene = new Scene(anchorPane);
        stage.setScene(scene);
        stage.show();

        stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());

                back.setLayoutX(0 * Main.stage.getScene().getWidth() / 640);
                back.setPrefWidth(45 * Main.stage.getScene().getWidth() / 640);

                on.setLayoutX(105 *  Main.stage.getScene().getWidth() / 640);
                on.setFont(Font.font((20)  * Main.stage.getScene().getWidth() / 640));

                off.setLayoutX(140 *  Main.stage.getScene().getWidth() / 640);
                off.setFont(Font.font((20)  * Main.stage.getScene().getWidth() / 640));

                ongoing.setLayoutX(25 * Main.stage.getScene().getWidth() / 640);
                ongoing.setPrefWidth(300 * Main.stage.getScene().getWidth() / 640);

                old.setLayoutX(25 * Main.stage.getScene().getWidth() / 640);
                old.setPrefWidth(300 * Main.stage.getScene().getWidth() / 640);

            }
        });

        stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());

                back.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                back.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                on.setLayoutY(35 * Main.stage.getScene().getHeight() / 360);
                on.setFont(Font.font((20) * Main.stage.getScene().getHeight() / 360));

                off.setLayoutY(205 * Main.stage.getScene().getHeight() / 360);
                off.setFont(Font.font((20) * Main.stage.getScene().getHeight() / 360));

                ongoing.setLayoutY(60 * Main.stage.getScene().getHeight() / 360);
                ongoing.setPrefHeight(100 * Main.stage.getScene().getHeight() / 360);

                old.setLayoutY(230 * Main.stage.getScene().getHeight() / 360);
                old.setPrefHeight(100 * Main.stage.getScene().getHeight() / 360);

            }
        });

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });

    }

    private void updateTimer() throws Exception {
        long currentTime = System.currentTimeMillis() / 1000; // Get current time in seconds

        if (currentTime >= endTime) {
            timerLabel.setText("Time's up!");
            c = true;
            Costumer.OngoingOrderToHistory();
            endTime += currentTime;
            new History().start(Main.stage);
        }
        else {
            long remainingTime = endTime - currentTime;
            long minutes = remainingTime / SECONDS_IN_MINUTE;
            long seconds = remainingTime % SECONDS_IN_MINUTE;

            timerLabel.setText(String.format("%02d:%02d", minutes, seconds));
        }
    }

}
