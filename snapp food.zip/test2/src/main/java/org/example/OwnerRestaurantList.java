package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javafx.util.Callback;
import logic.Costumer;
import logic.Owner;
import logic.Restaurant;
import logic.Server;

import java.net.URL;

public class OwnerRestaurantList extends Application {
    public static VBox vBox;
    @Override
    public void start(Stage stage) throws Exception {
        URL url = Main.class.getResource("/FXML/ownerRests.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/rest2.png").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        Button back = new Button("BACK");

        back.setLayoutX(15);
        back.setLayoutY(320);
        back.setPrefWidth(45);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");


        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Owner.logoutOwner();
                try {
                    new Main().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        ListView<String> l = Owner.getRest();
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        l.setOnMouseClicked(mouseEvent -> {
            ObservableList<String> observableList = l.getSelectionModel().getSelectedItems();
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < observableList.size(); i++) {
                s.append(observableList.get(i));
            }
            String ss = s.toString();
            String[] sss = ss.split(" ");
            Owner.selectRestaurant(Integer.parseInt(sss[0]));
            try {
                new RestOwn().start(Main.stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }


        });

        l.setCellFactory(param -> new ListCell<String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText(null);
                } else {
                    setText(item);
                    setFont(Font.font(15)); // Set desired font
//                    setTextFill(Color.BLUE); // Set desired text color
                }
            }
        });


        vBox = new VBox(l);
        vBox.setLayoutX(425);
        vBox.setLayoutY(25);
        vBox.setPrefWidth(200);
        vBox.setPrefHeight(315);

        anchorPane.getChildren().add(5, vBox);
        anchorPane.getChildren().add(back);

        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        Main.stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());
                TextField textField1 = (TextField) anchorPane.getChildren().get(0);
                TextField textField2 = (TextField) anchorPane.getChildren().get(1);
                TextField textField3 = (TextField) anchorPane.getChildren().get(2);

                Text text = (Text) anchorPane.getChildren().get(3);
                text.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                text.setFont(Font.font((int)(20 * Main.stage.getScene().getWidth() / 640)));

                Button button1 = (Button) anchorPane.getChildren().get(6);

                ImageView imageView = (ImageView) anchorPane.getChildren().get(4);
                imageView.setLayoutX(0 * Main.stage.getScene().getWidth() / 640);
                imageView.setFitWidth(280 * Main.stage.getScene().getWidth() / 640);

                back.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                back.setPrefWidth(45 * Main.stage.getScene().getWidth() / 640);

                button1.setPrefWidth(40 * Main.stage.getScene().getWidth() / 640);
                button1.setLayoutX(30 * Main.stage.getScene().getWidth() / 640);

                textField1.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);
                textField1.setLayoutX(30 * Main.stage.getScene().getWidth() / 640);

                textField2.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);
                textField2.setLayoutX(30 * Main.stage.getScene().getWidth() / 640);

                textField3.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);
                textField3.setLayoutX(30 * Main.stage.getScene().getWidth() / 640);

                vBox.setLayoutX(425 * Main.stage.getScene().getWidth() / 640);
                vBox.setPrefWidth(200 * Main.stage.getScene().getWidth() / 640);

            }
        });

        Main.stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());
                TextField textField1 = (TextField) anchorPane.getChildren().get(0);
                TextField textField2 = (TextField) anchorPane.getChildren().get(1);
                TextField textField3 = (TextField) anchorPane.getChildren().get(2);

                Button button1 = (Button) anchorPane.getChildren().get(6);

                Text text = (Text) anchorPane.getChildren().get(3);
                text.setLayoutY(35 * Main.stage.getScene().getWidth() / 640);

                ImageView imageView = (ImageView) anchorPane.getChildren().get(4);
                imageView.setLayoutY(150 * Main.stage.getScene().getHeight() / 360);
                imageView.setFitHeight(210 * Main.stage.getScene().getHeight() / 360);

                back.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                back.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                button1.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                button1.setLayoutY(150 * Main.stage.getScene().getHeight() / 360);

                textField1.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                textField1.setLayoutY(50 * Main.stage.getScene().getHeight() / 360);

                textField2.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                textField2.setLayoutY(80 * Main.stage.getScene().getHeight() / 360);

                textField3.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                textField3.setLayoutY(110 * Main.stage.getScene().getHeight() / 360);

                vBox.setLayoutY(25 * Main.stage.getScene().getHeight() / 360);
                vBox.setPrefHeight(315 * Main.stage.getScene().getHeight() / 360);

            }
        });

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });

    }
}