package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.*;

public class RestMenu extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/menu.jpg").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        anchorPane.setPrefWidth(640);
        anchorPane.setPrefHeight(360);

        TextField comment = new TextField(), search = new TextField(), r = new TextField();
        ProgressBar rate = new ProgressBar(Costumer.loggedInCostumer.selectedRestaurant.Rate());

        Button edit = new Button("Edit Rate"), back = new Button("BACK"), add = new Button("Add");
        VBox menu, comments;

        ImageView image = new ImageView(getClass().getResource("/menuu.jpg").toExternalForm());
        ImageView image2 = new ImageView(getClass().getResource("/search.png").toExternalForm());

        Text n = new Text("Add New Comment");

        ListView<String> l1 = Restaurant.getRestMenu(search.getText());
        ListView<String> l2 = Restaurant.getRestComments();


        comment.setLayoutX(15);
        comment.setLayoutY(80);
        comment.setPrefWidth(150);
        comment.setPrefHeight(25);

        search.setLayoutX(35);
        search.setLayoutY(0);
        search.setPrefWidth(340);
        search.setPrefHeight(25);

        r.setLayoutX(37);
        r.setLayoutY(220);
        r.setPrefWidth(100);
        r.setPrefHeight(25);

        rate.setLayoutX(40);
        rate.setLayoutY(190);
        rate.setPrefWidth(100);
        rate.setPrefHeight(20);

        edit.setLayoutX(55);
        edit.setLayoutY(250);
        edit.setPrefWidth(63);
        edit.setPrefHeight(25);

        back.setLayoutX(15);
        back.setLayoutY(320);
        back.setPrefWidth(45);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        add.setLayoutX(70);
        add.setLayoutY(120);
        add.setPrefWidth(38);
        add.setPrefHeight(25);

        image.setLayoutX(385);
        image.setLayoutY(0);
        image.setFitWidth(255);
        image.setFitHeight(360);
        image.setPreserveRatio(false);

        image2.setLayoutX(0);
        image2.setLayoutY(0);
        image2.setFitWidth(25);
        image2.setFitHeight(25);
        image2.setPreserveRatio(false);

        n.setLayoutX(0);
        n.setLayoutY(65);
        n.setFont(Font.font(20));

        anchorPane.getChildren().addAll(comment, search, r, rate, edit, back, add, image, image2, n);


        search.textProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
                l1.getItems().clear();

                ListView<String> l11 = Restaurant.getRestMenu(search.getText());

                for (int i = 0; i < l11.getItems().size(); i++) {
                    l1.getItems().add(l11.getItems().get(i));
                }
            }
        });

        add.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Costumer.addNewComment(comment.getText());
                l2.getItems().add(Costumer.loggedInCostumer.selectedRestaurant.comments.get(Costumer.loggedInCostumer.selectedRestaurant.comments.size() - 1).id + "        " + Costumer.loggedInCostumer.selectedRestaurant.comments.get(Costumer.loggedInCostumer.selectedRestaurant.comments.size() - 1).comment);
            }
        });

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new CostumerRestaurantList().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        edit.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Costumer.editRate(Integer.parseInt(r.getText()));
                rate.setProgress(Costumer.loggedInCostumer.selectedRestaurant.Rate());
            }
        });

        l1.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        l1.setOnMouseClicked(mouseEvent -> {
            ObservableList<String> observableList = l1.getSelectionModel().getSelectedItems();
            StringBuilder s = new StringBuilder();

            for (int i = 0; i < observableList.size(); i++) {
                s.append(observableList.get(i));
            }

            String ss = s.toString();
            String[] sss = ss.split(" ");

            Costumer.loggedInCostumer.selectedFood = Food.getFood(Integer.parseInt(sss[0]));

            try {
                new MenuFood().start(Main.stage);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        });

        menu = new VBox(l1);
        menu.setLayoutX(385);
        menu.setLayoutY(55);
        menu.setPrefWidth(170);
        menu.setPrefHeight(290);

        comments = new VBox(l2);
        comments.setLayoutX(205);
        comments.setLayoutY(55);
        comments.setPrefWidth(170);
        comments.setPrefHeight(290);

        anchorPane.getChildren().addAll(menu, comments);

        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        Main.stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());

                comment.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                comment.setPrefWidth(150 * Main.stage.getScene().getWidth() / 640);

                search.setLayoutX(35 * Main.stage.getScene().getWidth() / 640);
                search.setPrefWidth(340 * Main.stage.getScene().getWidth() / 640);

                r.setLayoutX(37 * Main.stage.getScene().getWidth() / 640);
                r.setPrefWidth(100 * Main.stage.getScene().getWidth() / 640);

                rate.setLayoutX(40 * Main.stage.getScene().getWidth() / 640);
                rate.setPrefWidth(100 * Main.stage.getScene().getWidth() / 640);

                edit.setLayoutX(55 * Main.stage.getScene().getWidth() / 640);
                edit.setPrefWidth(63 * Main.stage.getScene().getWidth() / 640);

                back.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                back.setPrefWidth(45 * Main.stage.getScene().getWidth() / 640);

                add.setLayoutX(70 * Main.stage.getScene().getWidth() / 640);
                add.setPrefWidth(38 * Main.stage.getScene().getWidth() / 640);

                image.setLayoutX(385 * Main.stage.getScene().getWidth() / 640);
                image.setFitWidth(255 * Main.stage.getScene().getWidth() / 640);

                image2.setLayoutX(0);
                image2.setFitWidth(25 * Main.stage.getScene().getWidth() / 640);

                n.setLayoutX(0);
                n.setFont(Font.font((20)  * Main.stage.getScene().getWidth() / 640));

                menu.setLayoutX(385 * Main.stage.getScene().getWidth() / 640);
                menu.setPrefWidth(170 * Main.stage.getScene().getWidth() / 640);

                comments.setLayoutX(205 * Main.stage.getScene().getWidth() / 640);
                comments.setPrefWidth(170 * Main.stage.getScene().getWidth() / 640);


            }
        });

        Main.stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());

                comment.setLayoutY(80 * Main.stage.getScene().getHeight() / 360);
                comment.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                search.setLayoutY(0);
                search.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                r.setLayoutY(220 * Main.stage.getScene().getHeight() / 360);
                r.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                rate.setLayoutY(190 * Main.stage.getScene().getHeight() / 360);
                rate.setPrefHeight(20 * Main.stage.getScene().getHeight() / 360);

                edit.setLayoutY(260 * Main.stage.getScene().getHeight() / 360);
                edit.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                back.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                back.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                add.setLayoutY(120 * Main.stage.getScene().getHeight() / 360);
                add.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                image.setLayoutY(0);
                image.setFitHeight(360 * Main.stage.getScene().getHeight() / 360);

                image2.setLayoutY(0);
                image2.setFitHeight(25 * Main.stage.getScene().getHeight() / 360);

                n.setLayoutY(65 * Main.stage.getScene().getHeight() / 360);
                n.setFont(Font.font((20) * Main.stage.getScene().getHeight() / 360));

                menu.setLayoutY(55 * Main.stage.getScene().getHeight() / 360);
                menu.setPrefHeight(290 * Main.stage.getScene().getHeight() / 360);

                comments.setLayoutY(55 * Main.stage.getScene().getHeight() / 360);
                comments.setPrefHeight(290 * Main.stage.getScene().getHeight() / 360);

            }
        });

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });

    }
}
