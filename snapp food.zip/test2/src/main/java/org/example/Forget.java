package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.Costumer;
import logic.Owner;
import logic.Server;

import java.net.URL;

public class Forget extends Application {
    @Override
    public void start(Stage stage) throws Exception {

        Stage stage1 = new Stage();

        URL url = Main.class.getResource("/FXML/forget.fxml");
        AnchorPane anchorPane = FXMLLoader.load(url);
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/login.jpeg").toExternalForm()))));

        Button back = new Button("BACK"), cap = new Button();
//        cap.setVisible(false);

        ImageView capPic = new ImageView(getClass().getResource("/capcha2.png").toExternalForm());

        back.setLayoutX(15);
        back.setLayoutY(320);
        back.setPrefWidth(45);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        cap.setLayoutX(215);
        cap.setLayoutY(303);
        cap.setPrefWidth(27);
        cap.setPrefHeight(27);

        capPic.setLayoutX(200);
        capPic.setLayoutY(286);
        capPic.setFitWidth(200);
        capPic.setFitHeight(60);
        capPic.setPreserveRatio(false);

        anchorPane.getChildren().addAll(back, cap);

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Capcha.c = false;
                try {
                    new Main().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        cap.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Capcha capcha = new Capcha();
                capcha.start(stage1);
            }
        });

        if(Capcha.c) {
            anchorPane.getChildren().remove(6);
            anchorPane.getChildren().add(capPic);
        }

        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        Main.stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());
                TextField textField1 = (TextField) anchorPane.getChildren().get(0);
                PasswordField textField2 = (PasswordField) anchorPane.getChildren().get(3);

                RadioButton checkBox1 = (RadioButton) anchorPane.getChildren().get(4);
                RadioButton checkBox2 = (RadioButton) anchorPane.getChildren().get(5);

                Button button1 = (Button) anchorPane.getChildren().get(2);

                ImageView imageView = (ImageView) anchorPane.getChildren().get(1);
                imageView.setLayoutX(150 * Main.stage.getScene().getWidth() / 640);
                imageView.setFitWidth(300 * Main.stage.getScene().getWidth() / 640);

                ImageView imageView2 = (ImageView) anchorPane.getChildren().get(6);
                imageView2.setLayoutX(200 * Main.stage.getScene().getWidth() / 640);
                imageView2.setFitWidth(200 * Main.stage.getScene().getWidth() / 640);

                capPic.setLayoutX(200 * Main.stage.getScene().getWidth() / 640);
                capPic.setFitWidth(200 * Main.stage.getScene().getWidth() / 640);

                back.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                back.setPrefWidth(45 * Main.stage.getScene().getWidth() / 640);

                button1.setPrefWidth(58 * Main.stage.getScene().getWidth() / 640);
                button1.setLayoutX(270 * Main.stage.getScene().getWidth() / 640);

                cap.setLayoutX(215 * Main.stage.getScene().getWidth() / 640);
                cap.setPrefWidth(27 * Main.stage.getScene().getWidth() / 640);

                textField1.setPrefWidth(200 * Main.stage.getScene().getWidth() / 640);
                textField1.setLayoutX(200 * Main.stage.getScene().getWidth() / 640);

                textField2.setPrefWidth(200 * Main.stage.getScene().getWidth() / 640);
                textField2.setLayoutX(200 * Main.stage.getScene().getWidth() / 640);

                checkBox1.setPrefWidth(73 * Main.stage.getScene().getWidth() / 640);
                checkBox1.setLayoutX(215 * Main.stage.getScene().getWidth() / 640);

                checkBox2.setPrefWidth(57 * Main.stage.getScene().getWidth() / 640);
                checkBox2.setLayoutX(340 * Main.stage.getScene().getWidth() / 640);
            }
        });

        Main.stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());
                TextField textField1 = (TextField) anchorPane.getChildren().get(0);
                PasswordField textField2 = (PasswordField) anchorPane.getChildren().get(3);

                Button button1 = (Button) anchorPane.getChildren().get(2);

                RadioButton checkBox1 = (RadioButton) anchorPane.getChildren().get(4);
                RadioButton checkBox2 = (RadioButton) anchorPane.getChildren().get(5);

                ImageView imageView = (ImageView) anchorPane.getChildren().get(1);
                imageView.setLayoutY(75 * Main.stage.getScene().getHeight() / 360);
                imageView.setFitHeight(60 * Main.stage.getScene().getHeight() / 360);

                ImageView imageView2 = (ImageView) anchorPane.getChildren().get(6);
                imageView2.setLayoutY(286 * Main.stage.getScene().getHeight() / 360);
                imageView2.setFitHeight(60 * Main.stage.getScene().getHeight() / 360);

                capPic.setLayoutY(286 * Main.stage.getScene().getHeight() / 360);
                capPic.setFitHeight(60 * Main.stage.getScene().getHeight() / 360);

                back.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                back.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                button1.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                button1.setLayoutY(220 * Main.stage.getScene().getHeight() / 360);

                cap.setLayoutY(303 * Main.stage.getScene().getHeight() / 360);
                cap.setPrefHeight(27 * Main.stage.getScene().getHeight() / 360);

                textField1.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                textField1.setLayoutY(145 * Main.stage.getScene().getHeight() / 360);

                textField2.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);
                textField2.setLayoutY(180 * Main.stage.getScene().getHeight() / 360);

                checkBox1.setPrefHeight(17 * Main.stage.getScene().getHeight() / 360);
                checkBox1.setLayoutY(260 * Main.stage.getScene().getHeight() / 360);

                checkBox2.setPrefHeight(17 * Main.stage.getScene().getHeight() / 360);
                checkBox2.setLayoutY(260 * Main.stage.getScene().getHeight() / 360);
            }
        });

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });
    }
}
