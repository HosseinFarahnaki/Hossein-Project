package org.example;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.Costumer;
import logic.Food;
import logic.Owner;
import logic.Server;


public class MenuFood extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/foodown.jpg").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        anchorPane.setPrefWidth(400);
        anchorPane.setPrefHeight(500);

        TextField name = new TextField(Costumer.loggedInCostumer.selectedFood.name);
        TextField price = new TextField(Double.toString(Costumer.loggedInCostumer.selectedFood.price));
        TextField dis = new TextField();

        ListView<String> l = Food.getFoodComments();
        VBox comments;


        if(Costumer.loggedInCostumer.selectedFood.discounts.size() > 0)
            dis.setText(Integer.toString(Costumer.loggedInCostumer.selectedFood.discounts.get(0).discountPercent) + " %");
        else
            dis.setText("null");

        name.setEditable(false);
        price.setEditable(false);
        dis.setEditable(false);

        name.setAlignment(Pos.CENTER);
        price.setAlignment(Pos.CENTER);
        dis.setAlignment(Pos.CENTER);

        Button back = new Button("Back");

        StringBuilder s = new StringBuilder();
        System.out.println("*" + Costumer.loggedInCostumer.selectedFood.name + "*");
        s.append("/" + Costumer.loggedInCostumer.selectedFood.name + ".jpg");

        ImageView image = new ImageView(getClass().getResource(s.toString()).toExternalForm());
        ImageView p = new ImageView(getClass().getResource("/plus.png").toExternalForm());

        ProgressBar r = new ProgressBar(Costumer.loggedInCostumer.selectedFood.Rate());

        name.setLayoutX(130);
        name.setLayoutY(215);
        name.setPrefWidth(150);
        name.setPrefHeight(25);

        price.setLayoutX(130);
        price.setLayoutY(250);
        price.setPrefWidth(150);
        price.setPrefHeight(25);

        dis.setLayoutX(35);
        dis.setLayoutY(235);
        dis.setPrefWidth(73);
        dis.setPrefHeight(25);

        p.setLayoutX(310);
        p.setLayoutY(220);
        p.setFitWidth(50);
        p.setFitHeight(50);
        p.setPreserveRatio(false);

        back.setLayoutX(15);
        back.setLayoutY(460);
        back.setPrefWidth(41);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        image.setLayoutX(115);
        image.setLayoutY(25);
        image.setFitWidth(180);
        image.setFitHeight(180);
        image.setPreserveRatio(false);

        r.setLayoutX(160);
        r.setLayoutY(185);
        r.setPrefWidth(85);
        r.setPrefHeight(18);

        comments = new VBox(l);
        comments.setLayoutX(135);
        comments.setLayoutY(285);
        comments.setPrefWidth(140);
        comments.setPrefHeight(180);


        anchorPane.getChildren().addAll(name, price, dis, p, back, image, r, comments);

        p.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Costumer.addFoodToCart();
                try {
                    new RestMenu().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new RestMenu().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });


        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });

    }

}
