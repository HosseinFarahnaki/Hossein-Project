package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import logic.Server;

import java.io.FileNotFoundException;
import java.net.URL;

public class Main extends Application {
    public static Stage stage;
    public static boolean changeTheme = false;
    public static boolean forget = false;
    public static void main(String[] args) throws FileNotFoundException {
        Server.readDataFromServer();

//        File file = new File("graph.txt");
//        Scanner raeder = new Scanner(file);
//        String[] firstline = raeder.nextLine().split(" ");
//        int node = Integer.parseInt(firstline[0]);
//        Graph graph = new Graph(node);
//        int mline = Integer.parseInt(firstline[1]);
//        for (int i = 0; i < mline; i++) {
//            String[] lines = raeder.nextLine().split(" ");
//            int source = Integer.parseInt(lines[0]);
//            int dest = Integer.parseInt(lines[1]);
//            int weight = Integer.parseInt(lines[2]);
//            graph.addEdge(source - 1, dest - 1, weight);
//        }
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        Main.stage = stage;
        URL url = Main.class.getResource("/FXML/enter.fxml");
        assert url != null;
        AnchorPane anchorPane = FXMLLoader.load(url);
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/enter.jpeg").toExternalForm()))));
        Scene scene = new Scene(anchorPane);

        stage.setScene(scene);
        stage.show();

        stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {

                anchorPane.setPrefWidth(stage.getScene().getWidth());
                Button button1 = (Button) anchorPane.getChildren().get(0);
                Button button2 = (Button) anchorPane.getChildren().get(1);

                button1.setPrefWidth(105 * stage.getScene().getWidth() / 640);
                button1.setLayoutX(14 * stage.getScene().getWidth() / 640);

                button2.setPrefWidth(119 * stage.getScene().getWidth() / 640);
                button2.setLayoutX(135 * stage.getScene().getWidth() / 640);
            }
        });
        stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {

                anchorPane.setPrefHeight(stage.getScene().getHeight());
                Button button1 = (Button) anchorPane.getChildren().get(0);
                Button button2 = (Button) anchorPane.getChildren().get(1);

                button1.setPrefHeight(75 * stage.getScene().getHeight() / 360);
                button1.setLayoutY(278 * stage.getScene().getHeight() / 360);

                button2.setPrefHeight(75 * stage.getScene().getHeight() / 360);
                button2.setLayoutY(278 * stage.getScene().getHeight() / 360);
            }
        });

    }
}