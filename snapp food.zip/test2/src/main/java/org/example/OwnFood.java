package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.*;

public class OwnFood extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/foodown2.jpg").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        anchorPane.setPrefWidth(400);
        anchorPane.setPrefHeight(500);

        VBox commnets;

        TextField name = new TextField(Owner.loggedInOwner.selectedFood.name);
        TextField price = new TextField(Double.toString(Owner.loggedInOwner.selectedFood.price));
        TextField active = new TextField("NOT ACTIVE");

        ListView<String> l = Food.getOwnComments();

        if(Owner.loggedInOwner.selectedFood.isActive)
            active.setText("ACTIVE");

        active.setEditable(false);

        name.setAlignment(Pos.CENTER);
        price.setAlignment(Pos.CENTER);
        active.setAlignment(Pos.CENTER);

        Button ac = new Button("Active");
        Button apply = new Button("Apply"), back = new Button("Back");
        Button discount = new Button("Disc");
        ImageView image = new ImageView(getClass().getResource("/delete.jpg").toExternalForm());


        name.setLayoutX(125);
        name.setLayoutY(90);
        name.setPrefWidth(150);
        name.setPrefHeight(25);

        price.setLayoutX(125);
        price.setLayoutY(130);
        price.setPrefWidth(150);
        price.setPrefHeight(25);

        active.setLayoutX(125);
        active.setLayoutY(170);
        active.setPrefWidth(150);
        active.setPrefHeight(25);

        apply.setLayoutX(150);
        apply.setLayoutY(320);
        apply.setPrefWidth(100);
        apply.setPrefHeight(43);
        apply.setFont(Font.font(20));
        apply.setStyle("-fx-background-color: #4caf50; -fx-text-fill: white;");

        ac.setLayoutX(175);
        ac.setLayoutY(215);
        ac.setPrefWidth(50);
        ac.setPrefHeight(25);
        ac.setStyle("-fx-background-color: #4caf50; -fx-text-fill: white;");

        back.setLayoutX(15);
        back.setLayoutY(460);
        back.setPrefWidth(41);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        image.setLayoutX(175);
        image.setLayoutY(260);
        image.setFitWidth(50);
        image.setFitHeight(50);
        image.setPreserveRatio(false);

        discount.setLayoutX(348);
        discount.setLayoutY(460);
        discount.setPrefWidth(38);
        discount.setPrefHeight(25);

        anchorPane.getChildren().addAll(name, price, active, apply, ac, back, image, discount);

        commnets = new VBox(l);
        commnets.setLayoutX(75);
        commnets.setLayoutY(385);
        commnets.setPrefWidth(250);
        commnets.setPrefHeight(90);

        anchorPane.getChildren().add(commnets);

        apply.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Apply Changes");
                alert.setContentText("Are you Sure ?");
                alert.showAndWait();

                if(active.getText().equals("ACTIVE"))
                    Restaurant.activeFood(Owner.loggedInOwner.selectedFood.id);
                else if(active.getText().equals("NOT ACTIVE"))
                    Restaurant.deactiveFood(Owner.loggedInOwner.selectedFood.id);
                Owner.editFoodName(Owner.loggedInOwner.selectedFood.id, name.getText());
                Owner.editFoodPrice(Owner.loggedInOwner.selectedFood.id, Double.parseDouble(price.getText()));
                try {
                    new RestOwn().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        image.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Delete Food");
                alert.setContentText("Are you Sure ?");
                alert.showAndWait();
                Owner.deleteFood(Owner.loggedInOwner.selectedFood.id);
                try {
                    new RestOwn().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Owner.loggedInOwner.selectedFood = null;
                try {
                    new RestOwn().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        ac.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if(active.getText().equals("ACTIVE"))
                    active.setText("NOT ACTIVE");
                else
                    active.setText("ACTIVE");
            }
        });

        discount.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                Stage d = new Stage();
                AnchorPane dd = new AnchorPane();
                Scene scene = new Scene(dd);
                dd.setPrefWidth(200);
                dd.setPrefHeight(200);

                TextField percent = new TextField();
                TextField time = new TextField();


                percent.setPromptText("Percent: ");
                time.setPromptText("Time: ");
                if(Owner.loggedInOwner.selectedFood.discounts.size() > 0) {
                    percent.setText(Integer.toString(Owner.loggedInOwner.selectedFood.discounts.get(0).discountPercent));
                    time.setText(Integer.toString(Owner.loggedInOwner.selectedFood.discounts.get(0).timeStamp));
                }

                Button change = new Button("Apply");

                percent.setLayoutX(25);
                percent.setLayoutY(25);
                percent.setPrefWidth(150);
                percent.setPrefHeight(25);

                time.setLayoutX(25);
                time.setLayoutY(60);
                time.setPrefWidth(150);
                time.setPrefHeight(25);

                change.setLayoutX(75);
                change.setLayoutY(160);
                change.setPrefWidth(47);
                change.setPrefHeight(25);

                dd.getChildren().addAll(percent, time, change);

                change.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent mouseEvent) {
                        if(Owner.loggedInOwner.selectedFood.discounts.size() > 0) {
                            Owner.loggedInOwner.selectedFood.discounts.get(0).discountPercent = Integer.parseInt(percent.getText());
                            Owner.loggedInOwner.selectedFood.discounts.get(0).timeStamp = Integer.parseInt(time.getText());
                        }
                        else
                            Owner.discountFood(Owner.loggedInOwner.selectedFood.id, Integer.parseInt(percent.getText()), Integer.parseInt(time.getText()));
                        d.close();
                    }
                });

                d.setScene(scene);
                d.show();

            }
        });

        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });

    }

}
