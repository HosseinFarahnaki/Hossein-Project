package org.example;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import logic.*;

import java.util.ArrayList;

public class Cart extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/cartBack.jpg").toExternalForm()))));
        if(Main.changeTheme)
            anchorPane.setBackground(Background.fill(new ImagePattern(new Image(getClass().getResource("/background.png").toExternalForm()))));

        anchorPane.setPrefWidth(640);
        anchorPane.setPrefHeight(360);

        VBox cart;
        ListView<String> l1 = Costumer.getCart();

        Button confirm = new Button("Confirm"), back = new Button("BACK");

        confirm.setLayoutX(320);
        confirm.setLayoutY(320);
        confirm.setPrefWidth(93);
        confirm.setPrefHeight(25);

        back.setLayoutX(15);
        back.setLayoutY(320);
        back.setPrefWidth(45);
        back.setPrefHeight(25);
        back.setStyle("-fx-background-color: #ff4136; -fx-text-fill: white;");

        anchorPane.getChildren().addAll(confirm, back);

        l1.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);

        cart = new VBox(l1);
        cart.setLayoutX(440);
        cart.setLayoutY(15);
        cart.setPrefWidth(200);
        cart.setPrefHeight(340);

        anchorPane.getChildren().addAll(cart);

        back.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new CostumerRestaurantList().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });

        confirm.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    new DeliveryOrder().start(Main.stage);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        });


        l1.setOnMouseClicked(mouseEvent -> {
            ObservableList<String> observableList = l1.getSelectionModel().getSelectedItems();
            StringBuilder s = new StringBuilder();
            for (int i = 0; i < observableList.size(); i++) {
                s.append(observableList.get(i));
            }
            String ss = s.toString();
            String[] sss = ss.split("        ");

            Costumer.loggedInCostumer.selectedFood = Food.getFood(Integer.parseInt(sss[1]));
            System.out.println(Integer.parseInt(sss[1]));

            Stage d = new Stage();
            AnchorPane dd = new AnchorPane();
            Scene scene = new Scene(dd);
            dd.setPrefWidth(200);
            dd.setPrefHeight(200);

            TextField number = new TextField();

            number.setPromptText("number: ");

            Button change = new Button("Apply");

            number.setLayoutX(25);
            number.setLayoutY(25);
            number.setPrefWidth(150);
            number.setPrefHeight(25);


            change.setLayoutX(75);
            change.setLayoutY(160);
            change.setPrefWidth(47);
            change.setPrefHeight(25);

            dd.getChildren().addAll(number, change);

            change.setOnMouseClicked(new EventHandler<MouseEvent>() {
                @Override
                public void handle(MouseEvent mouseEvent) {
                    if(Integer.parseInt(number.getText()) < 0) {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Invalid Number!");
                        alert.showAndWait();
                    }
                    else {
                        l1.getItems().clear();
                        ArrayList<Integer> tekrar = new ArrayList<>();
                        tekrar.add(100000);
                        l1.getItems().add("number         id        name        price");
                        for (int i = 0; i < Costumer.loggedInCostumer.cart.size(); i++) {
                            int counter = 0;
                            for (int j = 0; j < Costumer.loggedInCostumer.cart.size(); j++) {
                                if (Costumer.loggedInCostumer.cart.get(i).id == Costumer.loggedInCostumer.cart.get(j).id)
                                    counter++;
                            }
                            if (Costumer.loggedInCostumer.cart.get(i).id == Costumer.loggedInCostumer.selectedFood.id)
                                counter = Integer.parseInt(number.getText());
                            boolean check = true;
                            for (int j = 0; j < tekrar.size(); j++) {
                                if (tekrar.get(j) == Costumer.loggedInCostumer.cart.get(i).id) {
                                    check = false;
                                }
                            }
                            if (check) {
                                l1.getItems().add(counter + "        " + Costumer.loggedInCostumer.cart.get(i).id + "        " + Costumer.loggedInCostumer.cart.get(i).name + "        " + Costumer.loggedInCostumer.cart.get(i).price * counter);
                                tekrar.add(Costumer.loggedInCostumer.cart.get(i).id);
                            }
                        }

                        int c = 0;
                        for (int i = 0; i < Costumer.loggedInCostumer.cart.size(); i++)
                            if (Costumer.loggedInCostumer.cart.get(i).id == Costumer.loggedInCostumer.selectedFood.id)
                                c++;
                        if(c > Integer.parseInt(number.getText())) {
                            c -= Integer.parseInt(number.getText());
                            for (int i = 0; i < Costumer.loggedInCostumer.cart.size(); i++)
                                if (Costumer.loggedInCostumer.cart.get(i).id == Costumer.loggedInCostumer.selectedFood.id && c > 0) {
                                    c--;
                                    Costumer.loggedInCostumer.cart.remove(i);
                                }
                        }
                        else if(c < Integer.parseInt(number.getText())) {
                            for (int i = 0; i < Integer.parseInt(number.getText()) - c; i++) {
                                Costumer.addFoodToCart();
                            }
                        }

                        d.close();
                    }
                }
            });

            d.setScene(scene);
            d.show();

        });

        Scene scene = new Scene(anchorPane);
        Main.stage.setScene(scene);
        Main.stage.show();

        Main.stage.getScene().widthProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefWidth(Main.stage.getScene().getWidth());

                confirm.setLayoutX(320 * Main.stage.getScene().getWidth() / 640);
                confirm.setPrefWidth(93 * Main.stage.getScene().getWidth() / 640);

                back.setLayoutX(15 * Main.stage.getScene().getWidth() / 640);
                back.setPrefWidth(45 * Main.stage.getScene().getWidth() / 640);

                cart.setLayoutX(440 * Main.stage.getScene().getWidth() / 640);
                cart.setPrefWidth(200 * Main.stage.getScene().getWidth() / 640);

            }
        });

        Main.stage.getScene().heightProperty().addListener(new ChangeListener<Number>() {
            @Override
            public void changed(ObservableValue<? extends Number> observableValue, Number number, Number t1) {
                anchorPane.setPrefHeight(Main.stage.getScene().getHeight());

                confirm.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                confirm.setPrefHeight(93 * Main.stage.getScene().getHeight() / 360);

                back.setLayoutY(320 * Main.stage.getScene().getHeight() / 360);
                back.setPrefHeight(25 * Main.stage.getScene().getHeight() / 360);

                cart.setLayoutY(15 * Main.stage.getScene().getHeight() / 360);
                cart.setPrefHeight(340 * Main.stage.getScene().getHeight() / 360);


            }
        });

        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent windowEvent) {
                Owner.setLoggedInOwner(null);
                Costumer.setLoggedInCostumer(null);
                Server server = new Server();
                Server.writeDataToServer(server);
            }
        });

    }
}
