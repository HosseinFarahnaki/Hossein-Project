package logic;

import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

public class Food {
    public String name;
    public int restaurantId;
    public int id;
    public double price;
    public boolean isActive;
    public ArrayList<Discount> discounts;
    public ArrayList<Rate> rates;
    public ArrayList<Comment> comments;
    public static Food selectedFood;
    public static Random randNum = new Random();
    public static Set<Integer> set = new LinkedHashSet<Integer>();

    final public static ArrayList<Food> foods = new ArrayList<>();
    public static InputOutputProcessor inputOutput = InputOutputProcessor.getInstance();

    public Food(String name, double price, int restaurantId) {
        this.name = name;
        this.price = price;
        set.add(randNum.nextInt(1000));
        id = (int)set.toArray()[set.size()-1];
        isActive = true;
        discounts = new ArrayList<>();
        rates = new ArrayList<>();
        comments = new ArrayList<>();
        selectedFood = null;
        this.restaurantId = restaurantId;
    }

    public static ArrayList<Food> getFoods() {
        return foods;
    }

    public static Food getFood(int id) {
        int d = 0;
        boolean check = false;
        for (int i = 0; i < foods.size(); i++) {
            if(foods.get(i).id == id) {
                d = i;
                check = true;
                break;
            }
        }
        if(check)
            return foods.get(d);
        return null;
    }



    public static void displayRatings() {
        if(selectedFood == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            for (int i = 0; i < selectedFood.rates.size(); i++) {
                System.out.println(selectedFood.rates.get(i).getRate());
            }
        }
    }
    public static void displayComments() {
        if(selectedFood == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            for (int i = 0; i < selectedFood.comments.size(); i++) {
                System.out.println(selectedFood.comments.get(i).getComment());
            }
        }
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public void deactiveFood() {
        isActive = false;
    }
    public void activeFood() {
        isActive = true;
    }

    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public boolean isActive() {
        return isActive;
    }
    public ArrayList<Discount> getDiscounts() {
        return discounts;
    }
    public double getPrice() {
        return price;
    }
    public static Food getSelectedFood() {
        return selectedFood;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setPrice(double price) {
        this.price = price;
    }

    public int getRestaurantId() {
        return restaurantId;
    }

    public Rate getRate(String username) {
        int d = 0;
        boolean check = false;
        for (int i = 0; i < rates.size(); i++) {
            if(rates.get(i).getUserName() == username) {
                d = i;
                check = true;
                break;
            }
        }
        if(check)
            return rates.get(d);
        return null;
    }

    public ArrayList<Rate> getRates() {
        return rates;
    }

    public double Rate() {
        double rate = 0;
        for (int i = 0; i < rates.size(); i++) {
            rate += rates.get(i).rate;
        }
        if(rates.size() > 0)
            return (rate/10/rates.size());
        else
            return 1;
    }

    public static ListView<String> getFoodComments() {
        ListView<String> l = new ListView<>();
        l.getItems().add("id        comment        ");
        for (int i = 0; i < Costumer.loggedInCostumer.selectedFood.comments.size(); i++) {
            l.getItems().add(Costumer.loggedInCostumer.selectedFood.comments.get(i).id + "        " + Costumer.loggedInCostumer.selectedFood.comments.get(i).comment);
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getOwnComments() {
        ListView<String> l = new ListView<>();
        l.getItems().add("id        comment        ");
        for (int i = 0; i < Owner.loggedInOwner.selectedFood.comments.size(); i++) {
            l.getItems().add(Owner.loggedInOwner.selectedFood.comments.get(i).id + "        " + Owner.loggedInOwner.selectedFood.comments.get(i).comment);
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    //    public static void setSelectedFood(int id) {
//        if(getFood(id) == null)
//            System.out.println(CheckResult.ID_ERROR);
//        else {
//            selectedFood = getFood(id);
//            if(Owner.getLoggedInOwner().getUserName().equals(getFood(id).ownerUserName)) {
//                Owner.getLoggedInOwner().setSelectedFood(getFood(id));
//            }
//            else
//                Costumer.getLoggedInCostumer().setSelectedFood(getFood(id));
//        }
//    }
}
