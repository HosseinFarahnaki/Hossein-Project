package logic;

import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;

import java.util.ArrayList;

import static logic.Owner.loggedInOwner;

public class Restaurant implements Comparable<Restaurant>{
    public String name;
    public int id;
    public String ownerUserName;
    public int location;
    public static Restaurant selectedRestaurant;
    public String foodType;
    public ArrayList<Food> menu;
    public ArrayList<Order> orders;
    public ArrayList<Comment> comments;
    public ArrayList<Rate> rates;

    final public static ArrayList<Restaurant> restaurants = new ArrayList<>();
    public static InputOutputProcessor inputOutput = InputOutputProcessor.getInstance();

    public Restaurant(String name, String ownerUserName, int location, String foodType) {
        this.name = name;
        id = restaurants.size() + 1;
        this.location = location;
        this.ownerUserName = ownerUserName;
        this.foodType = foodType;
        menu = new ArrayList<>();
        orders = new ArrayList<>();
        comments = new ArrayList<>();
        rates = new ArrayList<>();
        selectedRestaurant = null;
    }
    static void addNewRestaurant(String name, int location, String foodType) {
        if(Owner.getLoggedInOwner() == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            inputOutput.printer(CheckResult.SUCCESSFUL);
            restaurants.add(new Restaurant(name, Owner.getLoggedInOwner().getUserName(), location, foodType));
            Owner.getLoggedInOwner().getRestaurants().add(restaurants.get(restaurants.size() - 1));
        }
    }

    public void addFood(Food food) {
        menu.add(food);
    }

    public void editLocation(int location) {
//        getRestaurant(this.id).location = location;
        this.location = location;
    }

    public void editFoodType(String foodType) {
        this.foodType = foodType;
//        getRestaurant(this.id).foodType = foodType;
        menu.clear();
    }

    public static void selectRestaurant(int id) {
        selectedRestaurant = restaurants.get(id-1);
    }

    public String getName() {
        return name;
    }
    public int getId() {
        return id;
    }
    public int getLocation() {
        return location;
    }
    public String getFoodType() {
        return foodType;
    }
    public ArrayList<Order> getOrders() {
        return orders;
    }
    public ArrayList<Food> getMenu() {
        return menu;
    }

    public static Restaurant getRestaurant(int id) {
        int d = 0;
        boolean check = false;
        for (int i = 0; i < restaurants.size(); i++) {
            if(restaurants.get(i).getId() == id && restaurants.get(i).getOwnerUserName().equals(Owner.getLoggedInOwner().getUserName())) {
                d = i;
                check = true;
                break;
            }
        }
        if(check)
            return restaurants.get(d);
        return null;
    }

    public Food getFood(int id) {
        int d = 0;
        boolean check = false;
        for (int i = 0; i < menu.size(); i++) {
            if(menu.get(i).getId() == id) {
                d = i;
                check = true;
                break;
            }
        }
        if(check)
            return menu.get(d);
        return null;
    }

//    Food getFood(String name) {
//        int d = 0;
//        boolean check = false;
//        for (int i = 0; i < menu.size(); i++) {
//            if(menu.get(i).getName().equals(name)) {
//                d = i;
//                check = true;
//                break;
//            }
//        }
//        if(check)
//            return menu.get(d);
//        return null;
//    }

    public static void deactiveFood(int id) {
        if(Owner.getLoggedInOwner() == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(Owner.getLoggedInOwner().getSelectedRestaurant() == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(Owner.getLoggedInOwner().getSelectedRestaurant().getFood(id) == null)
            inputOutput.printer(CheckResult.ID_ERROR);
        //////////////////////////////////////////////////////////////////////////////////////////////////////
        else {
            inputOutput.printer(CheckResult.SUCCESSFUL);
            Food.getFood(id).deactiveFood();
        }
    }

    public static void activeFood(int id) {
        if(Owner.getLoggedInOwner() == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(Owner.getLoggedInOwner().getSelectedRestaurant() == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(Owner.getLoggedInOwner().getSelectedRestaurant().getFood(id) == null)
            inputOutput.printer(CheckResult.ID_ERROR);
        else {
            inputOutput.printer(CheckResult.SUCCESSFUL);
            Food.getFood(id).activeFood();
        }
    }

    public Order getOrder(int orderId) {
        int d = 0;
        boolean check = false;
        for (int i = 0; i < orders.size(); i++) {
            if(orders.get(i).getId() == orderId) {
                d = i;
                check = true;
                break;
            }
        }
        if(check)
            return orders.get(d);
        return null;
    }

    @Override
    public int compareTo(Restaurant restaurant) {
        if(this.name.compareTo(restaurant.name) != 0)
            return this.name.compareTo(restaurant.name);
        else
            return this.id-restaurant.id;
    }

    public static ArrayList<Restaurant> getRestaurants() {
        return restaurants;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public Rate getRate(String username) {
        int d = 0;
        boolean check = false;
        for (int i = 0; i < rates.size(); i++) {
            if(rates.get(i).getUserName().equals(username)) {
                d = i;
                check = true;
                break;
            }
        }
        if(check)
            return rates.get(d);
        return null;
    }

    public static ListView<String> getOwnMenu() {
        ListView<String> l = new ListView<>();
        l.getItems().add("id        name        ");
        for (int i = 0; i < loggedInOwner.selectedRestaurant.menu.size(); i++) {
            l.getItems().add(loggedInOwner.selectedRestaurant.menu.get(i).id + "        " + loggedInOwner.selectedRestaurant.menu.get(i).name + "        " + loggedInOwner.selectedRestaurant.menu.get(i).price);
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getRestMenu(String search) {
        ListView<String> l = new ListView<>();
        l.getItems().add("id        name        ");
        for (int i = 0; i < Costumer.loggedInCostumer.selectedRestaurant.menu.size(); i++) {
                boolean check = true;
                for (int j = 0; j < search.length(); j++) {
                    if(search.charAt(j) != Costumer.loggedInCostumer.selectedRestaurant.menu.get(i).name.charAt(j)) {
                        check = false;
                        break;
                    }
                }
                if(check)
                    l.getItems().add(Costumer.loggedInCostumer.selectedRestaurant.menu.get(i).id + "        " + Costumer.loggedInCostumer.selectedRestaurant.menu.get(i).name + "        " + Costumer.loggedInCostumer.selectedRestaurant.menu.get(i).price);

        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getRestComments() {
        ListView<String> l = new ListView<>();
        l.getItems().add("id        comment        ");
        for (int i = 0; i < Costumer.loggedInCostumer.selectedRestaurant.comments.size(); i++) {
            l.getItems().add(Costumer.loggedInCostumer.selectedRestaurant.comments.get(i).id + "        " + Costumer.loggedInCostumer.selectedRestaurant.comments.get(i).comment);
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getOwnComments() {
        ListView<String> l = new ListView<>();
        l.getItems().add("id        comment        ");
        for (int i = 0; i < loggedInOwner.selectedRestaurant.comments.size(); i++) {
            l.getItems().add(loggedInOwner.selectedRestaurant.comments.get(i).id + "        " + loggedInOwner.selectedRestaurant.comments.get(i).comment);
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getFast(String search) {
        ListView<String> l = new ListView<>();
        l.getItems().add("id        name        ");
        for (int i = 0; i < restaurants.size(); i++) {
            if(restaurants.get(i).foodType.equals("FAST")) {
                boolean check = true;
                for (int j = 0; j < search.length(); j++) {
                    if(search.charAt(j) != restaurants.get(i).name.charAt(j)) {
                        check = false;
                        break;
                    }
                }
                if(check)
                    l.getItems().add(restaurants.get(i).id + "        " + restaurants.get(i).name);
            }
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getIrani(String search) {
        ListView<String> l = new ListView<>();
        l.getItems().add("id        name        ");
        for (int i = 0; i < restaurants.size(); i++) {
            if(restaurants.get(i).foodType.equals("IRANI")) {
                boolean check = true;
                for (int j = 0; j < search.length(); j++) {
                    if(search.charAt(j) != restaurants.get(i).name.charAt(j)) {
                        check = false;
                        break;
                    }
                }
                if(check)
                    l.getItems().add(restaurants.get(i).id + "        " + restaurants.get(i).name);
            }
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getOthers(String search) {
        ListView<String> l = new ListView<>();
        l.getItems().add("id        name        ");
        for (int i = 0; i < restaurants.size(); i++) {
            if(!restaurants.get(i).foodType.equals("FAST") && !restaurants.get(i).foodType.equals("IRANI")) {
                boolean check = true;
                for (int j = 0; j < search.length(); j++) {
                    if(search.charAt(j) != restaurants.get(i).name.charAt(j)) {
                        check = false;
                        break;
                    }
                }
                if(check)
                    l.getItems().add(restaurants.get(i).id + "        " + restaurants.get(i).name);
            }
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getOngoingOrder() {
        ListView<String> l = new ListView<>();
        ArrayList<Integer> tekrar = new ArrayList<>();
        tekrar.add(100000);
        l.getItems().add("number         id        name        price      Arrive");
        for (int i = 0; i < loggedInOwner.selectedRestaurant.orders.size(); i++) {
            int counter = 0;
            for (int j = 0; j < loggedInOwner.selectedRestaurant.orders.size(); j++) {
                if (loggedInOwner.selectedRestaurant.orders.get(i).foodId == loggedInOwner.selectedRestaurant.orders.get(j).foodId)
                    counter++;
            }
            boolean check = true;
            for (int j = 0; j < tekrar.size(); j++) {
                if (tekrar.get(j) == loggedInOwner.selectedRestaurant.orders.get(i).foodId) {
                    check = false;
                }
            }
            if (check) {
                l.getItems().add(counter + "        " + loggedInOwner.selectedRestaurant.orders.get(i).foodId + "        " + Food.getFood(loggedInOwner.selectedRestaurant.orders.get(i).foodId).name + "        " + loggedInOwner.selectedRestaurant.orders.get(i).foodPrice * counter + "        " + loggedInOwner.selectedRestaurant.orders.get(i).statusSent);
                tekrar.add(loggedInOwner.selectedRestaurant.orders.get(i).foodId);
            }
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public ArrayList<Rate> getRates() {
        return rates;
    }

    public double Rate() {
        double rate = 0;
        for (int i = 0; i < rates.size(); i++) {
            rate += rates.get(i).rate;
        }
        if(rates.size() > 0)
            return (rate/10/rates.size());
        else
            return 1;
    }

    public String getOwnerUserName() {
        return ownerUserName;
    }
}
