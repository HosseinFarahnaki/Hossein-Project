package logic;

public enum CheckResult {
    USER_NAME_ERROR, COST_ERROR, INVALID_COMMAND, ID_ERROR, PASSWORD_ERROR, NOT_ENOUGH_CREDIT, INVALID_PERCENT, SUCCESSFUL;

    CheckResult() {
    }
//    public static CheckResult[] values() {
//
//    }
//    public static CheckResult valueOf(String ) {
//
//    }


}
