package logic;

import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import org.example.Main;
import org.example.OwnerRestaurantList;

import static logic.Owner.loggedInOwner;
import static org.example.OwnerRestaurantList.vBox;

public class OwnerRestaurants {
    @FXML
    TextField namee, locationn, type;

    public void add(MouseEvent mouseEvent) throws Exception {
        Restaurant.addNewRestaurant(namee.getText(), Integer.parseInt(locationn.getText()), type.getText());

        new OwnerRestaurantList().start(Main.stage);

    }

}
