package logic;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import org.example.*;

public class enter {
    @FXML
    TextField userName, passWord;
    @FXML
    RadioButton costumer, owner;

    public void login(MouseEvent mouseEvent) throws Exception {
        if(costumer.isSelected()) {
            System.out.println("costumer");
            Costumer.loginCostumer(userName.getText(), passWord.getText());
        }
        else if(owner.isSelected()) {
            System.out.println("owner");
            Owner.loginOwner(userName.getText(), passWord.getText());
        }
    }


    public void signin(MouseEvent mouseEvent) throws Exception {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("ERROR");

        if(costumer.isSelected()) {
            if(Capcha.c)
                Costumer.addNewCostumer(userName.getText(), passWord.getText());
            else
                alert.showAndWait();
        }
        else if(owner.isSelected()) {
            if(Capcha.c)
                Owner.addNewOwner(userName.getText(), passWord.getText());
            else
                alert.showAndWait();
        }
        new Main().start(Main.stage);
    }

    public void forget(MouseEvent mouseEvent) throws Exception {
        Main.forget = true;
        new Forget().start(Main.stage);
    }

    public void signUp(MouseEvent mouseEvent) throws Exception {
        new Signup().start(Main.stage);
    }

    public void loginPage(MouseEvent mouseEvent) throws Exception {
        new Login().start(Main.stage);
    }

    public void change(MouseEvent mouseEvent) throws Exception {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("ERROR");

        if(costumer.isSelected()) {
            if(Capcha.c)
                Costumer.getCostumer(userName.getText()).password = passWord.getText();
            else
                alert.showAndWait();
        }
        else if(owner.isSelected()) {
            if(Capcha.c)
                Owner.getOwner(userName.getText()).password = passWord.getText();
            else
                alert.showAndWait();
        }
        new Login().start(Main.stage);
    }
}
