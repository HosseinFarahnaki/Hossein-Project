package logic;

import javafx.collections.ObservableList;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import org.example.CostumerRestaurantList;
import org.example.Main;
import org.example.Map;

import java.util.ArrayList;
import java.util.Collections;

public class Costumer{
    public String password;
    public String userName;
    public static Costumer loggedInCostumer;
    public Food selectedFood;
    public Restaurant selectedRestaurant;
    public boolean orderHistoryMenu;
    public boolean cartMenu;
    public int location;
    public ArrayList<Food> cart;
    public ArrayList<Order> orders;
    public ArrayList<Order> ordersHistory;
    public ArrayList<Comment> comments;
    public double cash;
    public ArrayList<Discount> discounts;
    final public static ArrayList<Costumer> costumers = new ArrayList<>();
    public static InputOutputProcessor inputOutput = InputOutputProcessor.getInstance();

    private Costumer(String password, String userName) {
        this.password = password;
        this.userName = userName;
        location = 10;
        cart = new ArrayList<>();
        orders = new ArrayList<>();
        ordersHistory = new ArrayList<>();
        discounts = new ArrayList<>();
        comments = new ArrayList<>();
        loggedInCostumer = null;
        selectedFood = null;
        selectedRestaurant = null;
        orderHistoryMenu = false;
        cartMenu = false;
        cash = 100;
    }

    public static void addNewCostumer(String userName, String password) throws Exception {
        if(loggedInCostumer != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(getCostumer(userName) != null || userName.length() < 8)
            inputOutput.printer(CheckResult.USER_NAME_ERROR);
        else if(password.length() < 8)
            inputOutput.printer(CheckResult.PASSWORD_ERROR);
        else {
            inputOutput.printer(CheckResult.SUCCESSFUL);
            costumers.add(new Costumer(password, userName));
            new Main().start(Main.stage);
        }
    }

    public static void loginCostumer(String userName, String password) throws Exception {
        if(loggedInCostumer != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(getCostumer(userName) == null || userName.length() < 8)
            inputOutput.printer(CheckResult.USER_NAME_ERROR);
        else if(password.length() < 8 || !(getCostumer(userName).password.equals(password)))
            inputOutput.printer(CheckResult.PASSWORD_ERROR);
        else {
            loggedInCostumer = getCostumer(userName);
            Owner.setLoggedInOwner(null);
            loggedInCostumer.orderHistoryMenu = false;
            loggedInCostumer.cartMenu = false;
            loggedInCostumer.selectedRestaurant = null;
            loggedInCostumer.selectedFood = null;
            inputOutput.printer(CheckResult.SUCCESSFUL);
            showRestaurantsList();
            new CostumerRestaurantList().start(Main.stage);
        }
    }

    public static void logoutCostumer() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            inputOutput.printer(CheckResult.SUCCESSFUL);
            loggedInCostumer = null;
        }
    }

    public static void showRestaurantsList() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            ArrayList<Restaurant> list = new ArrayList<>(Restaurant.getRestaurants());
            Collections.sort(list);
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i).getName() + " " + list.get(i).getId());
            }
        }
    }

    public static void searchRestaurant(String name) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.cartMenu || loggedInCostumer.orderHistoryMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            ArrayList<Restaurant> list = new ArrayList<>(Restaurant.getRestaurants());
            Collections.sort(list);
            boolean check = false;
            for (int i = 0; i < list.size(); i++) {
                if(list.get(i).getName().equals(name)) {
                    System.out.println(list.get(i).getName() + " " + list.get(i).getId());
                    check = true;
                }
            }
            if(!check)
                System.out.println("NOT_FOUND");
        }
    }

    public static void searchFood(String name) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedFood != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.cartMenu || loggedInCostumer.orderHistoryMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            ArrayList<Food> list = new ArrayList<>(loggedInCostumer.selectedRestaurant.getMenu());
            boolean check = false;
            for (int i = 0; i < list.size(); i++) {
                if(list.get(i).getName().equals(name)) {
                    System.out.println(list.get(i).getName() + " " + list.get(i).getId());
                    check = true;
                }
            }
            if(!check)
                System.out.println("NOT_FOUND");
        }
    }

    static Costumer getCostumer(String userName) {
        int d = 0;
        boolean check = false;
        for (int i = 0; i < costumers.size(); i++) {
            if(costumers.get(i).userName.equals(userName)) {
                d = i;
                check = true;
                break;
            }
        }
        if(check)
            return costumers.get(d);
        return null;
    }

//    public static void selectFood(int id) {
//        if(loggedInCostumer.selectedRestaurant == null)
//            System.out.println(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.selectedRestaurant.getFood(id) == null)
//            System.out.println(CheckResult.ID_ERROR);
//        else
//            loggedInCostumer.selectedFood = loggedInCostumer.selectedRestaurant.getFood(id);
//    }


//    public static void displayOpenOrders() {
//        if(loggedInCostumer == null)
//            System.out.println(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.selectedRestaurant == null)
//            System.out.println(CheckResult.INVALID_COMMAND);
//        else {
//            for (int i = 0; i < loggedInCostumer.orders.size(); i++) {
//                System.out.println(loggedInCostumer.orders.get(i).getFoodId() + " " + loggedInCostumer.orders.get(i).statusSent());
//            }
//        }
//    }

    static Costumer getLoggedInCostumer() {
        return loggedInCostumer;
    }

    public static ArrayList<Costumer> getCostumers() {
        return costumers;
    }

    public int getLocation() {
        return location;
    }

    public Food getSelectedFood() {
        return selectedFood;
    }

    public static void selectRestaurant(int id) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);

        else if(Restaurant.getRestaurants().size() < id || id < 1)
            inputOutput.printer(CheckResult.ID_ERROR);
        else {
            loggedInCostumer.selectedRestaurant = Restaurant.getRestaurants().get(id - 1);
            for (int i = 0; i < loggedInCostumer.selectedRestaurant.getMenu().size(); i++) {
                System.out.println(loggedInCostumer.selectedRestaurant.getMenu().get(i).getName() + " " + loggedInCostumer.selectedRestaurant.getMenu().get(i).getPrice() + " " + loggedInCostumer.selectedRestaurant.getMenu().get(i).getId());
            }

        }
    }

    public static void selectFood(int id) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.selectedRestaurant.getFood(id) == null)
//            System.out.println("NAME_ERROR");
        else {
            loggedInCostumer.selectedFood = Food.getFood(id);
        }
    }

    public static void displayComments() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.ID_ERROR);
        else if(loggedInCostumer.selectedRestaurant == null)
            inputOutput.printer(CheckResult.INVALID_PERCENT);
        else if(loggedInCostumer.cartMenu || loggedInCostumer.orderHistoryMenu)
            inputOutput.printer(CheckResult.COST_ERROR);
        else if(loggedInCostumer.selectedFood != null)
            for (int i = 0; i < loggedInCostumer.selectedFood.getComments().size(); i++) {
                System.out.println(loggedInCostumer.selectedFood.getComments().get(i).getComment() + " username: " + loggedInCostumer.selectedFood.getComments().get(i).getUserName());
            }
        else
            for (int i = 0; i < loggedInCostumer.selectedRestaurant.getComments().size(); i++) {
                System.out.println(loggedInCostumer.selectedRestaurant.getComments().get(i).getComment() + " username: " + loggedInCostumer.selectedRestaurant.getComments().get(i).getUserName());
            }

    }

    public static void addNewComment(String comment) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.selectedRestaurant == null)
//            inputOutput.printer(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.cartMenu || loggedInCostumer.orderHistoryMenu)
//            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedFood != null) {
            boolean check = false;
            for (int i = 0; i < loggedInCostumer.ordersHistory.size(); i++) {
                if(loggedInCostumer.ordersHistory.get(i).getFoodId() == loggedInCostumer.selectedFood.getId()) {
                    check = true;
                    break;
                }
            }
            if(check)
                loggedInCostumer.selectedFood.getComments().add(new Comment(loggedInCostumer.userName, comment));
            else
                inputOutput.printer(CheckResult.INVALID_COMMAND);
        }
        else {
            inputOutput.printer(CheckResult.SUCCESSFUL);
            loggedInCostumer.selectedRestaurant.getComments().add(new Comment(loggedInCostumer.userName, comment));
        }
    }

    public static void editComment(int id, String comment) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.cartMenu || loggedInCostumer.orderHistoryMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedFood != null) {

        }
        else {

        }
    }

    public static void displayRating() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.cartMenu || loggedInCostumer.orderHistoryMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedFood != null)
            for (int i = 0; i < loggedInCostumer.selectedFood.getRates().size(); i++) {
                System.out.println(loggedInCostumer.selectedFood.getRates().get(i).getRate() + " username: " + loggedInCostumer.selectedFood.getRates().get(i).getUserName());
            }
        else
            for (int i = 0; i < loggedInCostumer.selectedRestaurant.getRates().size(); i++) {
                System.out.println(loggedInCostumer.selectedRestaurant.getRates().get(i).getRate() + " username: " + loggedInCostumer.selectedRestaurant.getRates().get(i).getUserName());
            }

    }

    public static void submitRate(int rate) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.selectedRestaurant == null)
//            inputOutput.printer(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.cartMenu || loggedInCostumer.orderHistoryMenu)
//            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedFood != null) {
            boolean check = false;
            for (int i = 0; i < loggedInCostumer.ordersHistory.size(); i++) {
                if(loggedInCostumer.ordersHistory.get(i).getFoodId() == loggedInCostumer.selectedFood.getId()) {
                    check = true;
                    break;
                }
            }
            if(check)
                loggedInCostumer.selectedFood.getRates().add(new Rate(loggedInCostumer.userName, rate));
            else
                inputOutput.printer(CheckResult.INVALID_COMMAND);
        }
        else
            loggedInCostumer.selectedRestaurant.getRates().add(new Rate(loggedInCostumer.userName, rate));
    }

    public static void editRate(int rate) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.selectedRestaurant == null)
//            inputOutput.printer(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.cartMenu || loggedInCostumer.orderHistoryMenu)
//            inputOutput.printer(CheckResult.INVALID_COMMAND);
//        else if(loggedInCostumer.selectedFood != null)
//            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if((loggedInCostumer.selectedFood != null && loggedInCostumer.selectedRestaurant.getRate(loggedInCostumer.userName) == null) || (loggedInCostumer.selectedFood != null && loggedInCostumer.selectedFood.getRate(loggedInCostumer.userName) == null))
            submitRate(rate);
        else
            loggedInCostumer.selectedRestaurant.getRate(loggedInCostumer.userName).setRate(rate);
    }

    public static void addFoodToCart() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedFood == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(!loggedInCostumer.selectedFood.isActive)
            System.out.println("NOT ACTIVE");
        else {
//            inputOutput.printer(CheckResult.SUCCESSFUL);
            loggedInCostumer.cart.add(loggedInCostumer.selectedFood);
        }
    }

    public static void accessOrderHistory() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            loggedInCostumer.orderHistoryMenu = true;
            for (int i = 0; i < loggedInCostumer.ordersHistory.size(); i++) {
                System.out.println("order " + i + 1);
            }
        }
    }

    public static void selectOrder(int id) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(!loggedInCostumer.orderHistoryMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(id > loggedInCostumer.ordersHistory.size() || id < 1)
            inputOutput.printer(CheckResult.ID_ERROR);
        else
            System.out.println(loggedInCostumer.ordersHistory.get(id-1).getRestaurantName() + " " + Food.getFood(loggedInCostumer.ordersHistory.get(id-1).getFoodId()).getName() + " " + Food.getFood(loggedInCostumer.ordersHistory.get(id-1).getFoodId()).getPrice());
    }

    public static void displayCartStatus() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            loggedInCostumer.cartMenu = true;
            for (int i = 0; i < loggedInCostumer.cart.size(); i++) {
                System.out.println(loggedInCostumer.cart.get(i).getName() + " " + loggedInCostumer.cart.get(i).getPrice());
            }
        }
    }

    public static void confirmOrder() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.cash < cartPrice(loggedInCostumer.cart))
            inputOutput.printer(CheckResult.NOT_ENOUGH_CREDIT);
        else {
            for (int i = 0; i < loggedInCostumer.cart.size(); i++) {
                loggedInCostumer.orders.add(new Order(loggedInCostumer.userName, loggedInCostumer.cart.get(i)));
                loggedInCostumer.cash -= loggedInCostumer.cart.get(i).getPrice();
                Restaurant.getRestaurants().get(loggedInCostumer.cart.get(i).getRestaurantId()-1).getOrders().add(loggedInCostumer.orders.get(loggedInCostumer.orders.size() - 1));
            }

            loggedInCostumer.cart.clear();
            inputOutput.printer(CheckResult.SUCCESSFUL);
        }
    }

    public static void OngoingOrderToHistory() {
        loggedInCostumer.ordersHistory.addAll(loggedInCostumer.orders);
        for (int i = 0; i < loggedInCostumer.orders.size(); i++) {
            loggedInCostumer.orders.get(i).statusSent = true;
        }

        loggedInCostumer.orders.clear();
    }

    public static double cartPrice(ArrayList<Food> cart) {
        int price = 0;
        for (int i = 0; i < cart.size(); i++) {
            price += cart.get(i).getPrice();
        }
        return price;
    }

    public static void chargeAccount(double cash) {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.cartMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.orderHistoryMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
//            inputOutput.printer(CheckResult.SUCCESSFUL);
            loggedInCostumer.cash += cash;
        }
    }

    public static void displayAccountCharge() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.cartMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.orderHistoryMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            System.out.println(loggedInCostumer.cash);
        }
    }


    public void back() {
        if(selectedFood != null)
            selectedFood = null;
        else if(selectedRestaurant != null)
            selectedRestaurant = null;
        else if(cartMenu)
            cartMenu = false;
        else if(orderHistoryMenu)
            orderHistoryMenu = false;
        else
            inputOutput.printer(CheckResult.INVALID_COMMAND);
    }

    public static void showEstimatedDeliveryTime() {
        if(loggedInCostumer == null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.selectedRestaurant != null)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.cartMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else if(loggedInCostumer.orderHistoryMenu)
            inputOutput.printer(CheckResult.INVALID_COMMAND);
        else {
            int time = 0;
            for (int i = 0; i < loggedInCostumer.orders.size(); i++) {
                if(loggedInCostumer.orders.get(i).getPath().getTime() > time)
                    time = loggedInCostumer.orders.get(i).getPath().getTime();
            }
            System.out.println(time);
        }
    }

    public static ListView<String> getCart() {
        ListView<String> l = new ListView<>();
        ArrayList<Integer> tekrar = new ArrayList<>();
        tekrar.add(100000);
        l.getItems().add("number         id        name        price");
        for (int i = 0; i < Costumer.loggedInCostumer.cart.size(); i++) {
            int counter = 0;
            for (int j = 0; j < Costumer.loggedInCostumer.cart.size(); j++) {
                if (Costumer.loggedInCostumer.cart.get(i).id == Costumer.loggedInCostumer.cart.get(j).id)
                    counter++;
            }
            boolean check = true;
            for (int j = 0; j < tekrar.size(); j++) {
                if (tekrar.get(j) == Costumer.loggedInCostumer.cart.get(i).id) {
                    check = false;
                }
            }
            if (check) {
                l.getItems().add(counter + "        " + Costumer.loggedInCostumer.cart.get(i).id + "        " + Costumer.loggedInCostumer.cart.get(i).name + "        " + Costumer.loggedInCostumer.cart.get(i).price * counter);
                tekrar.add(Costumer.loggedInCostumer.cart.get(i).id);
            }
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getOngoingOrder() {
        ListView<String> l = new ListView<>();
        ArrayList<Integer> tekrar = new ArrayList<>();
        tekrar.add(100000);
        l.getItems().add("n         id        name        price            distance");
        for (int i = 0; i < Costumer.loggedInCostumer.orders.size(); i++) {
            int counter = 0;
            for (int j = 0; j < Costumer.loggedInCostumer.orders.size(); j++) {
                if (Costumer.loggedInCostumer.orders.get(i).foodId == Costumer.loggedInCostumer.orders.get(j).foodId)
                    counter++;
            }
            boolean check = true;
            for (int j = 0; j < tekrar.size(); j++) {
                if (tekrar.get(j) == Costumer.loggedInCostumer.orders.get(i).foodId) {
                    check = false;
                }
            }
            if (check) {
//                l.getItems().add(String.format("%d %9d %12s %8.1f %8d",counter , Costumer.loggedInCostumer.orders.get(i).foodId, Food.getFood(Costumer.loggedInCostumer.orders.get(i).foodId).name, Costumer.loggedInCostumer.orders.get(i).foodPrice * counter , Map.pathcost(Costumer.loggedInCostumer.orders.get(i).costumerLocation, Costumer.loggedInCostumer.orders.get(i).restaurantLocation)));
                l.getItems().add(counter + "        " + Costumer.loggedInCostumer.orders.get(i).foodId + "        " + Food.getFood(Costumer.loggedInCostumer.orders.get(i).foodId).name + "        " + Costumer.loggedInCostumer.orders.get(i).foodPrice * counter + "        " + Map.pathcost(Costumer.loggedInCostumer.orders.get(i).costumerLocation, Costumer.loggedInCostumer.orders.get(i).restaurantLocation));
                tekrar.add(Costumer.loggedInCostumer.orders.get(i).foodId);
            }
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> getHistoryOrder() {
        ListView<String> l = new ListView<>();
//        ArrayList<Integer> tekrar = new ArrayList<>();
//        tekrar.add(100000);
        l.getItems().add("id        name        price");
        for (int i = 0; i < Costumer.loggedInCostumer.ordersHistory.size(); i++) {
//            int counter = 0;
//            for (int j = 0; j < Costumer.loggedInCostumer.ordersHistory.size(); j++) {
//                if (Costumer.loggedInCostumer.ordersHistory.get(i).foodId == Costumer.loggedInCostumer.ordersHistory.get(j).foodId)
//                    counter++;
//            }
//            boolean check = true;
//            for (int j = 0; j < tekrar.size(); j++) {
//                if (tekrar.get(j) == Costumer.loggedInCostumer.ordersHistory.get(i).foodId) {
//                    check = false;
//                }
//            }
//            if (check) {
////                l.getItems().add(String.format("%2d %9d %12s %8.1f %8d",counter , Costumer.loggedInCostumer.ordersHistory.get(i).foodId, Food.getFood(Costumer.loggedInCostumer.ordersHistory.get(i).foodId).name , Costumer.loggedInCostumer.ordersHistory.get(i).foodPrice * counter , Map.pathcost(Costumer.loggedInCostumer.ordersHistory.get(i).costumerLocation, Costumer.loggedInCostumer.ordersHistory.get(i).restaurantLocation)));

                l.getItems().add(Costumer.loggedInCostumer.ordersHistory.get(i).foodId + "        " + Food.getFood(Costumer.loggedInCostumer.ordersHistory.get(i).foodId).name + "        " + Costumer.loggedInCostumer.ordersHistory.get(i).foodPrice);
//                tekrar.add(Costumer.loggedInCostumer.ordersHistory.get(i).foodId);
//            }
        }
        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }

    public static ListView<String> recum() {
        ListView<String> l = new ListView<>();
        ArrayList<Integer> tekrar = new ArrayList<>();
        ArrayList<Integer> tt = new ArrayList<>();
        ArrayList<Integer> mm = new ArrayList<>();
        int[] m = new int[1000];

        tekrar.add(100000);
        l.getItems().add("id        name        price");
        for (int i = 0; i < Costumer.loggedInCostumer.ordersHistory.size(); i++) {
            int counter = 0;
            for (int j = 0; j < Costumer.loggedInCostumer.ordersHistory.size(); j++) {
                if (Costumer.loggedInCostumer.ordersHistory.get(i).foodId == Costumer.loggedInCostumer.ordersHistory.get(j).foodId)
                    counter++;
            }
            boolean check = true;
            for (int j = 0; j < tekrar.size(); j++) {
                if (tekrar.get(j) == Costumer.loggedInCostumer.ordersHistory.get(i).foodId) {
                    check = false;
                }
            }
            if (check) {
//                l.getItems().add(String.format("%2d %9d %12s %8.1f %8d",counter , Costumer.loggedInCostumer.ordersHistory.get(i).foodId, Food.getFood(Costumer.loggedInCostumer.ordersHistory.get(i).foodId).name , Costumer.loggedInCostumer.ordersHistory.get(i).foodPrice * counter , Map.pathcost(Costumer.loggedInCostumer.ordersHistory.get(i).costumerLocation, Costumer.loggedInCostumer.ordersHistory.get(i).restaurantLocation)));
                tt.add(counter);
                mm.add(i);
                tekrar.add(Costumer.loggedInCostumer.ordersHistory.get(i).foodId);
            }
        }



        int[] s = new int[tt.size()];


        for (int i = 0; i < tt.size(); i++) {
            s[i] = tt.get(i);
        }
        for (int i = 0; i < mm.size(); i++) {
            m[i] = mm.get(i);
        }
        for (int i = 0; i < tt.size(); i++) {
            for (int j = 0; j < i; j++) {
                if(s[j] < s[i]) {
                    int a = s[j];
                    s[j] = s[i];
                    s[i] = a;
                    a = m[j];
                    m[j] = m[i];
                    m[i] = a;
                }
            }
        }

        s[0] = Restaurant.getRestaurants().get(Food.getFood(Costumer.loggedInCostumer.ordersHistory.get(m[0]).foodId).restaurantId - 1).menu.get(0).id;
        s[1] = Restaurant.getRestaurants().get(Food.getFood(Costumer.loggedInCostumer.ordersHistory.get(m[1]).foodId).restaurantId - 1).menu.get(1).id;
        s[2] = Restaurant.getRestaurants().get(Food.getFood(Costumer.loggedInCostumer.ordersHistory.get(m[2]).foodId).restaurantId - 1).menu.get(2).id;

        l.getItems().add(s[0] + "        " + Food.getFood(s[0]).name + "        " + Food.getFood(s[0]).price * .8);
        l.getItems().add(s[1] + "        " + Food.getFood(s[1]).name + "        " + Food.getFood(s[1]).price * .8);
        l.getItems().add(s[2] + "        " + Food.getFood(s[2]).name + "        " + Food.getFood(s[2]).price * .8);

        l.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        return l;
    }



    public Restaurant getSelectedRestaurant() {
        return selectedRestaurant;
    }

    public static void setLoggedInCostumer(Costumer loggedInCostumer) {
        Costumer.loggedInCostumer = loggedInCostumer;
    }
}
