package logic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;

public class Graph {
    private int V;
    private int[][] graph;

    public Graph(int V)
    {
        this.V = V;
        graph = new int[V][V];
    }

    public void addEdge(int source, int destination, int weight) {
        graph[source][destination] = weight;
        graph[destination][source] = weight; //دو طرفه بودن گراف
    }

    public int getEdgeWeight (int source, int destination) {
        return graph[source][destination] ;
    }

    public List<Integer> aStar(int source, int destination) {

        PriorityQueue<Node> pq = new PriorityQueue<>();
        int[] distance = new int[V];
        int[] parent = new int[V];
        boolean[] visited = new boolean[V];
        Arrays.fill(distance, Integer.MAX_VALUE);
        Arrays.fill(parent, -1);
        distance[source] = 0;
        pq.offer(new Node(source, 0));

        while (!pq.isEmpty()) {
            Node current = pq.poll();
            int currentNode = current.id;

            if (currentNode == destination) {
                break;
            }

            if (visited[currentNode]) {
                continue;
            }

            visited[currentNode] = true;

            for (int neighbor = 0; neighbor < V; neighbor++) {
                if (graph[currentNode][neighbor] != 0) {
                    int newCost = distance[currentNode] + graph[currentNode][neighbor];
                    if (newCost < distance[neighbor]) {
                        distance[neighbor] = newCost;
                        parent[neighbor] = currentNode ;
                        int priority = newCost;
                        pq.offer(new Node(neighbor, priority));
                    }
                }
            }
        }

        return buildPath(parent, destination);
    }

    private List<Integer> buildPath(int[] parent, int destination) {
        List<Integer> path = new ArrayList<>();
        int current = destination;
        while (current != -1) {
            path.add(0, current);
            current = parent[current];
        }
        return path;
    }

    static class Node implements Comparable<Node> {
        int id;
        int priority;

        public Node(int id, int priority) {
            this.id = id;
            this.priority = priority;
        }

        @Override
        public int compareTo(Node other) {
            return Integer.compare(priority, other.priority);
        }
    }
}
