package logic;

import javafx.scene.control.Alert;

import java.util.Scanner;

public class InputOutputProcessor {
    public static final InputOutputProcessor instance = new InputOutputProcessor();
    final Scanner scanner = new Scanner(System.in);
    private InputOutputProcessor() {

    }
    boolean printer(CheckResult a) {
        if(a == CheckResult.SUCCESSFUL) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Successful!");
            alert.showAndWait();
            System.out.println("Successful!");
            return true;
        }
        if(a == CheckResult.COST_ERROR) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Cost!!");
            alert.showAndWait();

            System.out.println("Invalid Cost!");
            return true;
        }
        if(a == CheckResult.ID_ERROR) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid id!");
            alert.showAndWait();

            System.out.println("Invalid id!");
            return true;
        }
        if(a == CheckResult.INVALID_COMMAND) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Command!");
            alert.showAndWait();

            System.out.println("Invalid Command!");
            return true;
        }
        if(a == CheckResult.NOT_ENOUGH_CREDIT) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Low Credit!");
            alert.showAndWait();

            System.out.println("Low Credit!");
            return true;
        }
        if(a == CheckResult.PASSWORD_ERROR) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Password!");
            alert.showAndWait();

            System.out.println("Invalid Password!");
            return true;
        }
        if(a == CheckResult.INVALID_PERCENT) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Percent!");
            alert.showAndWait();

            System.out.println("Invalid Percent");
            return true;
        }
        if(a == CheckResult.USER_NAME_ERROR) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Invalid Username!");
            alert.showAndWait();

            System.out.println("Invalid Username!");
            return true;
        }
        return false;
    }
    public static InputOutputProcessor getInstance() {
        return instance;
    }

    public Scanner getScanner() {
        return this.scanner;
    }
}


