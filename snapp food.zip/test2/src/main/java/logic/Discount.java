package logic;

public class Discount {
    public String code;
    public int timeStamp;
    public int discountPercent;
    public boolean isActive;

    public Discount(int timeStamp, int discountPercent) {
        isActive = true;
        this.timeStamp = timeStamp;
        this.discountPercent = discountPercent;
    }

    public boolean isActive() {
        return isActive;
    }
}
